<?php $__env->startSection('title', 'Créer une nouvelle catégorie'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Créer une nouvelle catégorie</h1>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('admin.categories.store')); ?>">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nom</label>
                <input type="text" class="form-control" id="name" name="name" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"></textarea>
            </div>
            <div class="mb-3">
                <label for="color" class="form-label">Couleur</label>
                <input type="color" class="form-control form-control-color" id="color" name="color" value="#000000" required>
            </div>
            <div class="mb-3">
                <label for="icon" class="form-label">Icône</label>
                <input type="text" class="form-control" id="icon" name="icon" placeholder="Ex: fas fa-icon" required>
            </div>
            <div class="mb-3 form-check">
                <input type="hidden" name="is_active" value="0">
                <input type="checkbox" class="form-check-input" id="is_active" name="is_active" value="1">
                <label class="form-check-label" for="is_active">Active</label>
            </div>
            <div class="d-flex justify-content-between">
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-secondary">Annuler</a>
                <button type="submit" class="btn btn-primary">Créer</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views\admin\categories\create.blade.php ENDPATH**/ ?>