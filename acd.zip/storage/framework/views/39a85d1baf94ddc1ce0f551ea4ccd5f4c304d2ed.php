<?php $__env->startSection('title', 'Gestion des projets'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Gestion des Projets</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-sm btn-primary">
            <i class="fas fa-plus me-1"></i>Nouveau Projet
        </a>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-4">
                <label for="status" class="form-label">Statut</label>
                <select class="form-select" id="status" name="status">
                    <option value="">Tous les statuts</option>
                    <option value="active" <?php echo e(request('status') == 'active' ? 'selected' : ''); ?>>En cours</option>
                    <option value="completed" <?php echo e(request('status') == 'completed' ? 'selected' : ''); ?>>Terminé</option>
                    <option value="suspended" <?php echo e(request('status') == 'suspended' ? 'selected' : ''); ?>>Suspendu</option>
                </select>
            </div>
            <div class="col-md-4">
                <label for="category" class="form-label">Catégorie</label>
                <select class="form-select" id="category" name="category">
                    <option value="">Toutes les catégories</option>
                    <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-4">
                <label for="search" class="form-label">Recherche</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="search" name="search"
                           value="<?php echo e(request('search')); ?>" placeholder="Titre, description...">
                    <button class="btn btn-outline-secondary" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Projects Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Liste des Projets (<?php echo e($projects->total()); ?>)</h5>
    </div>
    <div class="card-body">
        <?php if($projects->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Projet</th>
                        <th>Catégorie</th>
                        <th>Statut</th>
                        <th>Période</th>
                        <th>Budget</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <?php if($project->featured_image): ?>
                                <img src="<?php echo e(asset('storage/' . $project->featured_image)); ?>"
                                     class="me-3 rounded" width="50" height="50" style="object-fit: cover;">
                                <?php endif; ?>
                                <div>
                                    <h6 class="mb-0"><?php echo e($project->title); ?></h6>
                                    <small class="text-muted"><?php echo e(Str::limit($project->excerpt, 60)); ?></small>
                                    <?php if($project->is_featured): ?>
                                    <span class="badge bg-warning ms-2">Phare</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge bg-primary"><?php echo e(Str::limit($category->name, 10)); ?></span>
                        </td>
                         <td>
                            <span class="badge
                                <?php if($project->status == 'active'): ?> bg-success
                                <?php elseif($project->status == 'completed'): ?> bg-danger
                                <?php else: ?> bg-purple
                                <?php endif; ?>
                                text-white">
                                <?php if($project->status == 'active'): ?> En cours
                                <?php elseif($project->status == 'completed'): ?> Terminé
                                <?php else: ?> Suspendu <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <?php if($project->start_date): ?>
                            <?php echo e($project->start_date->format('M Y')); ?>

                            <?php if($project->end_date): ?> - <?php echo e($project->end_date->format('M Y')); ?> <?php endif; ?>
                            <?php else: ?>
                            <span class="text-muted">Non définie</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($project->budget): ?>
                            <?php echo e(number_format($project->budget, 0, ',', ' ')); ?> FCFA
                            <?php else: ?>
                            <span class="text-muted">Non défini</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.projects.show', $project)); ?>"
                                   class="btn btn-sm btn-outline-info" title="Voir">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.projects.edit', $project)); ?>"
                                   class="btn btn-sm btn-outline-primary" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.projects.destroy', $project)); ?>"
                                      class="d-inline" onsubmit="return confirm('Êtes-vous sûr ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($projects->appends(request()->query())->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-project-diagram fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Aucun projet trouvé</h5>
            <a href="<?php echo e(route('admin.projects.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i>Créer le premier projet
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\Projets clients\act4communities\act4communities\resources\views/admin/projects/index.blade.php ENDPATH**/ ?>