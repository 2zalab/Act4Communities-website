<?php $__env->startSection('title', 'Actualités'); ?>
<?php $__env->startSection('description', 'Découvrez les dernières actualités et articles d\'Act for Communities sur le développement communautaire'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<section class="hero-news-section position-relative overflow-hidden">
    <!-- Background overlay -->
    <div class="hero-overlay"></div>

    <!-- Content -->
    <div class="container position-relative">
        <div class="row align-items-center min-vh-50">
            <div class="col-lg-8 py-3 mx-auto text-center text-white">
                <!-- Breadcrumb -->
                <!--nav aria-label="breadcrumb" class="mb-4">
                    <ol class="breadcrumb justify-content-center bg-transparent">
                        <li class="breadcrumb-item">
                            <a href="<?php echo e(route('home')); ?>" class="text-white-50 text-decoration-none">
                                <i class="fas fa-home me-1"></i><?php echo e(__('Accueil')); ?>

                            </a>
                        </li>
                        <li class="breadcrumb-item active text-white" aria-current="page">
                            <?php echo e(__('Actualités')); ?>

                        </li>
                    </ol>
                </nav-->

                <!-- Main title -->
                <h1 class="display-3 fw-bold mb-4 text-shadow">
                    <?php echo e(__('Actualités & Blog')); ?>

                </h1>

                <!-- Subtitle -->
                <p class="lead mb-4 fs-4 text-shadow">
                    <?php echo e(__('Suivez nos activités, nos réflexions et les nouvelles du développement communautaire au Cameroun')); ?>

                </p>

                <!-- Statistics -->
                <div class="row justify-content-center mt-5">
                    <div class="col-md-4 col-6 mb-3">
                        <div class="stat-item">
                            <h3 class="display-6 fw-bold text-warning mb-1"><?php echo e($posts->total()); ?></h3>
                            <p class="mb-0 text-white-75"><?php echo e(__('Articles publiés')); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 col-6 mb-3">
                        <div class="stat-item">
                            <h3 class="display-6 fw-bold text-warning mb-1"><?php echo e($categories->count()); ?></h3>
                            <p class="mb-0 text-white-75"><?php echo e(__('Catégories')); ?></p>
                        </div>
                    </div>
                    <div class="col-md-4 col-6 mb-3">
                        <div class="stat-item">
                            <h3 class="display-6 fw-bold text-warning mb-1"><?php echo e(date('Y') - 2020); ?>+</h3>
                            <p class="mb-0 text-white-75"><?php echo e(__('Années d\'expérience')); ?></p>
                        </div>
                    </div>
                    <!--div class="col-md-3 col-6 mb-3">
                        <div class="stat-item">
                            <h3 class="display-6 fw-bold text-warning mb-1">15+</h3>
                            <p class="mb-0 text-white-75"><?php echo e(__('Projets réalisés')); ?></p>
                        </div>
                    </div-->
                </div>

                <!-- CTA Button -->
                <!--div class="mt-5">
                    <a href="#articles" class="btn btn-warning btn-lg px-4 py-3 rounded-pill smooth-scroll">
                        <i class="fas fa-arrow-down me-2"></i><?php echo e(__('Découvrir nos articles')); ?>

                    </a>
                </div-->
            </div>
        </div>
    </div>

    <!-- Scroll indicator -->
    <div class="scroll-indicator position-absolute bottom-0 start-50 translate-middle-x mb-4">
        <div class="scroll-arrow">
            <i class="fas fa-chevron-down text-white"></i>
        </div>
    </div>
</section>

<!-- Search and Filters -->
<section id="articles" class="py-4 bg-white shadow-sm">
    <div class="container-fluid px-5">
        <form method="GET" action="<?php echo e(route('posts.index')); ?>" class="row align-items-end">
            <div class=" col-md-6 mb-3">
                <label for="search" class="form-label"><?php echo e(__('Rechercher')); ?></label>
                <div class="input-group">
                    <input type="text" class="form-control" id="search" name="search"
                           value="<?php echo e(request('search')); ?>" placeholder="<?php echo e(__('Titre, contenu...')); ?>">
                    <button class="btn btn-outline-secondary" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <label for="category" class="form-label"><?php echo e(__('Catégorie')); ?></label>
                <select class="form-select" id="category" name="category">
                    <option value="all"><?php echo e(__('Toutes les catégories')); ?></option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->slug); ?>" <?php echo e(request('category') == $category->slug ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?> (<?php echo e($category->posts_count); ?>)
                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-lg-3 col-md-6 mb-3">
                <label for="type" class="form-label"><?php echo e(__('Type')); ?></label>
                <select class="form-select" id="type" name="type">
                    <option value="all"><?php echo e(__('Tous les types')); ?></option>
                    <option value="article" <?php echo e(request('type') == 'article' ? 'selected' : ''); ?>><?php echo e(__('Article')); ?></option>
                    <option value="news" <?php echo e(request('type') == 'news' ? 'selected' : ''); ?>><?php echo e(__('Actualité')); ?></option>
                    <option value="event" <?php echo e(request('type') == 'event' ? 'selected' : ''); ?>><?php echo e(__('Événement')); ?></option>
                </select>
            </div>
            <div class="col-lg-2 col-md-6 mb-3">
                <button type="submit" class="btn btn-primary w-100">
                    <i class="fas fa-filter me-1"></i><?php echo e(__('Filtrer')); ?>

                </button>
            </div>
        </form>
    </div>
</section>

<div class="-fluid px-5 py-5">
    <div class="row">
        <!-- Main Content -->
        <div class="col-lg-8">
            <!-- Featured Posts -->
            <?php if($featuredPosts->count() > 0 && !request()->hasAny(['search', 'category', 'type'])): ?>
            <section class="mb-5">
                <h2 class="section-title fw-bold mb-4"><?php echo e(__('À la une')); ?></h2>
                <div class="row">
                    <?php $__currentLoopData = $featuredPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-8 mb-4">
                        <article class="card h-100 border-0 shadow">
                            <?php if($post->featured_image): ?>
                            <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>"
                                 class="card-img-top" alt="<?php echo e($post->title); ?>"
                                 style="height: 200px; object-fit: cover;">
                            <?php endif; ?>
                            <div class="card-body d-flex flex-column">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="badge bg-primary d-block text-truncate" style="width: 80%;" id="categoryBadge"><?php echo e($post->category->name); ?></span>
                                    <small class="text-muted"><?php echo e($post->published_at->format('d/m/Y')); ?></small>
                                </div>
                                <h5 class="card-title">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none">
                                        <?php echo e($post->title); ?>

                                    </a>
                                </h5>
                                <p class="card-text flex-grow-1"><?php echo e($post->excerpt); ?></p>
                                <div class="d-flex justify-content-between align-items-center mt-auto">
                                    <!--small class="text-muted">
                                        <i class="fas fa-user me-1"></i><?php echo e($post->user->name); ?>

                                    </small-->
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="btn btn-sm btn-outline-primary">
                                        <?php echo e(__('Lire la suite')); ?>

                                    </a>
                                </div>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </section>
            <?php endif; ?>

            <!-- All Posts -->
            <section>
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h2 class="fw-bold">
                        <?php if(request()->hasAny(['search', 'category', 'type'])): ?>
                            <?php echo e(__('Résultats de recherche')); ?>

                        <?php else: ?>
                            <?php echo e(__('Toutes les actualités')); ?>

                        <?php endif; ?>
                    </h2>
                    <span class="text-muted"><?php echo e($posts->total()); ?> <?php echo e(__('article(s)')); ?></span>
                </div>

                <?php if($posts->count() > 0): ?>
                <div class="row">
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 mb-4">
                        <article class="card h-100 border-0 shadow-sm">
                            <?php if($post->featured_image): ?>
                            <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>"
                                 class="card-img-top" alt="<?php echo e($post->title); ?>"
                                 style="height: 200px; object-fit: cover;">
                            <?php endif; ?>
                            <div class="card-body d-flex flex-column">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="badge bg-secondary"><?php echo e(\Illuminate\Support\Str::limit($post->category->name, 25)); ?></span>
                                    <span class="badge
                                        <?php if($post->type == 'news'): ?> bg-info
                                        <?php elseif($post->type == 'event'): ?> bg-warning
                                        <?php else: ?> bg-success <?php endif; ?>">
                                        <?php if($post->type == 'news'): ?> <?php echo e(__('Actualité')); ?>

                                        <?php elseif($post->type == 'event'): ?> <?php echo e(__('Événement')); ?>

                                        <?php else: ?> <?php echo e(__('Article')); ?> <?php endif; ?>
                                    </span>
                                </div>
                                <h5 class="card-title">
                                    <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="text-decoration-none">
                                        <?php echo e($post->title); ?>

                                    </a>
                                </h5>
                                <p class="card-text flex-grow-1"><?php echo e($post->excerpt); ?></p>
                                <div class="mt-auto">
                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                        <small class="text-muted">
                                            <i class="fas fa-user me-1"></i><?php echo e($post->user->name); ?>

                                        </small>
                                        <small class="text-muted">
                                            <i class="fas fa-calendar me-1"></i><?php echo e($post->published_at->format('d/m/Y')); ?>

                                        </small>
                                    </div>
                                    <div class="d-flex justify-content-between align-items-center">
                                        <small class="text-muted">
                                            <i class="fas fa-eye me-1"></i><?php echo e($post->views_count); ?> <?php echo e(__('vues')); ?>

                                        </small>
                                        <a href="<?php echo e(route('posts.show', $post->slug)); ?>" class="btn btn-sm btn-outline-primary">
                                            <?php echo e(__('Lire la suite')); ?>

                                        </a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Pagination -->
                <div class="d-flex justify-content-center mt-4">
                    <?php echo e($posts->appends(request()->query())->links()); ?>

                </div>
                <?php else: ?>
                <!-- No Posts -->
                <div class="text-center py-5">
                    <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
                    <h4 class="text-muted"><?php echo e(__('Aucun article trouvé')); ?></h4>
                    <p class="text-muted"><?php echo e(__('Essayez de modifier vos critères de recherche')); ?></p>
                    <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary">
                        <?php echo e(__('Voir tous les articles')); ?>

                    </a>
                </div>
                <?php endif; ?>
            </section>
        </div>

        <!-- Sidebar -->
        <div class="col-lg-4">
            <!-- Recent Posts -->
            <?php if($recentPosts->count() > 0): ?>
            <div class="card shadow mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-clock me-2"></i><?php echo e(__('Articles récents')); ?></h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex mb-3 <?php echo e(!$loop->last ? 'pb-3 border-bottom' : ''); ?>">
                        <?php if($recent->featured_image): ?>
                        <img src="<?php echo e(asset('storage/' . $recent->featured_image)); ?>"
                             class="me-3 rounded" alt="<?php echo e($recent->title); ?>"
                             style="width: 60px; height: 60px; object-fit: cover;">
                        <?php endif; ?>
                        <div class="flex-grow-1">
                            <h6 class="mb-1">
                                <a href="<?php echo e(route('posts.show', $recent->slug)); ?>" class="text-decoration-none">
                                    <?php echo e(Str::limit($recent->title, 50)); ?>

                                </a>
                            </h6>
                            <small class="text-muted">
                                <i class="fas fa-calendar me-1"></i><?php echo e($recent->published_at->format('d/m/Y')); ?>

                            </small>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Categories -->
            <?php if($categories->count() > 0): ?>
            <div class="card shadow mb-4">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-tags me-2"></i><?php echo e(__('Catégories')); ?></h5>
                </div>
                <div class="card-body">
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <a href="<?php echo e(route('posts.index', ['category' => $category->slug])); ?>"
                           class="text-decoration-none">
                            <?php echo e($category->name); ?>

                        </a>
                        <span class="badge bg-light text-dark"><?php echo e($category->posts_count); ?></span>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Newsletter -->
            <div class="card shadow mb-4 bg-primary text-white">
                <div class="card-body text-center">
                    <h5><i class="fas fa-envelope me-2"></i><?php echo e(__('Newsletter')); ?></h5>
                    <p class="mb-3"><?php echo e(__('Recevez nos dernières actualités')); ?></p>
                    <form action="<?php echo e(route('contact.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="type" value="general">
                        <input type="hidden" name="subject" value="Inscription Newsletter">
                        <div class="mb-3">
                            <input type="email" class="form-control" name="email"
                                   placeholder="<?php echo e(__('Votre email')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <input type="text" class="form-control" name="name"
                                   placeholder="<?php echo e(__('Votre nom')); ?>" required>
                        </div>
                        <input type="hidden" name="message" value="Demande d'inscription à la newsletter">
                        <button type="submit" class="btn btn-light w-100">
                            <?php echo e(__('S\'inscrire')); ?>

                        </button>
                    </form>
                </div>
            </div>

            <!-- Social Links -->
            <div class="card shadow">
                <div class="card-header">
                    <h5 class="mb-0"><i class="fas fa-share-alt me-2"></i><?php echo e(__('Suivez-nous')); ?></h5>
                </div>
                <div class="card-body text-center">
                    <div class="d-flex justify-content-center gap-3">
                        <a href="#" class="btn btn-outline-primary btn-sm">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="#" class="btn btn-outline-info btn-sm">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                        <a href="#" class="btn btn-outline-dark btn-sm">
                            <i class="fab fa-twitter"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Ajoutez ces styles CSS dans votre section <style> du layout principal -->
<style>
.hero-news-section {
    background: linear-gradient(135deg, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.7)),
                url('<?php echo e(asset("images/news-hero-bg.webp")); ?>') center/cover no-repeat;
    min-height: 80vh;
    display: flex;
    align-items: center;
    position: relative;
}

.hero-news-section::before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.4);
    z-index: 1;
}

.hero-news-section .container {
    z-index: 2;
}

.hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg,
        rgba(0, 0, 0, 0.85) 0%,
        rgba(0, 185, 129, 0.75) 50%,
        rgba(245, 158, 11, 0.8) 100%);
    z-index: 1;
}

.min-vh-50 {
    min-height: 50vh;
}

.text-shadow {
    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.5);
}

.text-white-75 {
    color: rgba(255, 255, 255, 0.85) !important;
}

.text-white-50 {
    color: rgba(255, 255, 255, 0.7) !important;
}

.stat-item {
    padding: 1rem;
    border-radius: 10px;
    background: rgba(255, 255, 255, 0.1);
    backdrop-filter: blur(10px);
    border: 1px solid rgba(255, 255, 255, 0.2);
    transition: transform 0.3s ease, background 0.3s ease;
}

.stat-item:hover {
    transform: translateY(-5px);
    background: rgba(255, 255, 255, 0.15);
}

.breadcrumb-item + .breadcrumb-item::before {
    color: rgba(255, 255, 255, 0.7);
}

.scroll-indicator {
    z-index: 2;
}

.scroll-arrow {
    animation: bounce 2s infinite;
}

@keyframes bounce {
    0%, 20%, 50%, 80%, 100% {
        transform: translateY(0);
    }
    40% {
        transform: translateY(-10px);
    }
    60% {
        transform: translateY(-5px);
    }
}

.smooth-scroll {
    scroll-behavior: smooth;
}

/* Responsive adjustments */
@media (max-width: 768px) {
    .hero-news-section {
        min-height: 70vh;
    }

    .display-3 {
        font-size: 2.5rem !important;
    }

    .stat-item {
        margin-bottom: 1rem;
    }
}

@media (max-width: 576px) {
    .hero-news-section {
        min-height: 60vh;
    }

    .display-3 {
        font-size: 2rem !important;
    }

    .lead {
        font-size: 1.1rem !important;
    }
}
</style>

<!-- Script pour le smooth scroll (à ajouter dans votre section scripts) -->
<script>
document.addEventListener('DOMContentLoaded', function() {
    // Smooth scroll pour les liens avec la classe smooth-scroll
    document.querySelectorAll('.smooth-scroll').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views\frontend\posts\index.blade.php ENDPATH**/ ?>