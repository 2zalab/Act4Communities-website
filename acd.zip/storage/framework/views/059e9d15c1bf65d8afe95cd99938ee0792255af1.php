<?php $__env->startSection('title', 'Demandes de partenariat'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <i class="fas fa-envelope me-2 text-primary"></i>Demandes de partenariat
    </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.partners.index')); ?>" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Retour aux partenaires
        </a>
    </div>
</div>

<!-- Statistics -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($stats['total']); ?></h4>
                        <p class="mb-0">Total demandes</p>
                    </div>
                    <div>
                        <i class="fas fa-inbox fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($stats['pending']); ?></h4>
                        <p class="mb-0">En attente</p>
                    </div>
                    <div>
                        <i class="fas fa-clock fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($stats['under_review']); ?></h4>
                        <p class="mb-0">En examen</p>
                    </div>
                    <div>
                        <i class="fas fa-search fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($stats['approved']); ?></h4>
                        <p class="mb-0">Approuvées</p>
                    </div>
                    <div>
                        <i class="fas fa-check-circle fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Filtres -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.partnership-requests.index')); ?>">
            <div class="row g-3">
                <div class="col-md-3">
                    <select name="status" class="form-select">
                        <option value="">Tous les statuts</option>
                        <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>En attente</option>
                        <option value="under_review" <?php echo e(request('status') == 'under_review' ? 'selected' : ''); ?>>En examen</option>
                        <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>Approuvé</option>
                        <option value="rejected" <?php echo e(request('status') == 'rejected' ? 'selected' : ''); ?>>Rejeté</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="partnership_type" class="form-select">
                        <option value="">Tous les types</option>
                        <option value="financial" <?php echo e(request('partnership_type') == 'financial' ? 'selected' : ''); ?>>Financier</option>
                        <option value="technical" <?php echo e(request('partnership_type') == 'technical' ? 'selected' : ''); ?>>Technique</option>
                        <option value="strategic" <?php echo e(request('partnership_type') == 'strategic' ? 'selected' : ''); ?>>Stratégique</option>
                        <option value="academic" <?php echo e(request('partnership_type') == 'academic' ? 'selected' : ''); ?>>Académique</option>
                    </select>
                </div>
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="Rechercher..." value="<?php echo e(request('search')); ?>">
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search me-1"></i>Filtrer
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Messages d'alerte -->
<?php if(session('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<?php if(session('error')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fas fa-exclamation-circle me-2"></i><?php echo e(session('error')); ?>

    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
</div>
<?php endif; ?>

<!-- Requests Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Liste des demandes (<?php echo e($partnershipRequests->total()); ?>)</h5>
    </div>
    <div class="card-body">
        <?php if($partnershipRequests->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Organisation</th>
                        <th>Contact</th>
                        <th>Type</th>
                        <th>Statut</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $partnershipRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div>
                                <strong><?php echo e($request->org_name); ?></strong>
                                <div class="small text-muted">
                                    <span class="badge badge-sm bg-secondary"><?php echo e($request->org_type_name); ?></span>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div>
                                <strong><?php echo e($request->contact_name); ?></strong>
                                <div class="small text-muted"><?php echo e($request->contact_email); ?></div>
                                <?php if($request->contact_phone): ?>
                                <div class="small text-muted"><?php echo e($request->contact_phone); ?></div>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <span class="badge
                                <?php if($request->partnership_type == 'financial'): ?> bg-success
                                <?php elseif($request->partnership_type == 'technical'): ?> bg-info
                                <?php elseif($request->partnership_type == 'strategic'): ?> bg-primary
                                <?php else: ?> bg-warning <?php endif; ?>">
                                <?php echo e($request->partnership_type_name); ?>

                            </span>
                        </td>
                        <td>
                            <span class="<?php echo e($request->status_badge); ?>">
                                <?php echo e($request->status_name); ?>

                            </span>
                        </td>
                        <td>
                            <div class="small">
                                <?php echo e($request->created_at->format('d/m/Y')); ?>

                                <div class="text-muted"><?php echo e($request->created_at->format('H:i')); ?></div>
                            </div>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.partnership-requests.show', $request)); ?>"
                                   class="btn btn-sm btn-outline-info" title="Voir">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <?php if($request->status == 'pending'): ?>
                                <form method="POST" action="<?php echo e(route('admin.partnership-requests.under-review', $request)); ?>" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('PATCH'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-primary" title="Mettre en examen">
                                        <i class="fas fa-search"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                                <?php if(in_array($request->status, ['pending', 'under_review'])): ?>
                                <a href="<?php echo e(route('admin.partnership-requests.edit', $request)); ?>"
                                   class="btn btn-sm btn-outline-warning" title="Traiter">
                                    <i class="fas fa-cogs"></i>
                                </a>
                                <?php endif; ?>
                                <?php if(!in_array($request->status, ['approved'])): ?>
                                <form method="POST" action="<?php echo e(route('admin.partnership-requests.destroy', $request)); ?>"
                                      class="d-inline" onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette demande ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($partnershipRequests->withQueryString()->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-inbox fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Aucune demande trouvée</h5>
            <p class="text-muted">Les nouvelles demandes de partenariat apparaîtront ici</p>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views/admin/partnership-requests/index.blade.php ENDPATH**/ ?>