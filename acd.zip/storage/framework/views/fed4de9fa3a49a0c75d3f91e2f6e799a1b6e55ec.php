<?php echo e($slot); ?>

<?php /**PATH D:\MIT\act4communities\act4communities\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>