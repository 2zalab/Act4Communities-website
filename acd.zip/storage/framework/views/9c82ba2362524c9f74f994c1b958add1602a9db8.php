<?php $__env->startSection('title', 'Gestion des catégories'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Gestion des Catégories</h1>
</div>

<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Liste des Catégories</h5>
    </div>
    <div class="card-body">
        <div class="mb-3">
            <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i> Nouvelle Catégorie
            </a>
        </div>
        <?php if($categories->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Nom</th>
                        <th>Description</th>
                        <th>Couleur</th>
                        <th>Icône</th>
                        <th>Statut</th>
                        <th>Projets</th>
                        <th>Articles</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($category->name); ?></td>
                        <td><?php echo e(Str::limit($category->description, 50)); ?></td>
                        <td>
                            <span class="badge" style="background-color: <?php echo e($category->color); ?>; color: white;">
                                <?php echo e($category->color); ?>

                            </span>
                        </td>
                        <td>
                            <i class="<?php echo e($category->icon); ?>"></i>
                        </td>
                        <td>
                            <?php if($category->is_active): ?>
                                <span class="badge bg-success">Active</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">Inactive</span>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($category->projects_count); ?></td>
                        <td><?php echo e($category->posts_count); ?></td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.categories.edit', $category)); ?>" class="btn btn-sm btn-outline-primary">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.categories.destroy', $category)); ?>" class="d-inline" onsubmit="return confirm('Êtes-vous sûr ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-folder fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Aucune catégorie trouvée</h5>
            <a href="<?php echo e(route('admin.categories.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i> Créer la première catégorie
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views\admin\categories\index.blade.php ENDPATH**/ ?>