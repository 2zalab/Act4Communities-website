<?php $__env->startSection('title', 'Partenariat'); ?>
<?php $__env->startSection('description', 'Découvrez les opportunités de partenariat avec Act for Communities pour amplifier notre impact'); ?>

<?php $__env->startSection('content'); ?>
<!-- Header -->
<section class="py-5 bg-primary text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white"><?php echo e(__('Accueil')); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('contact.index')); ?>" class="text-white"><?php echo e(__('Contact')); ?></a></li>
                        <li class="breadcrumb-item active text-white"><?php echo e(__('Partenariat')); ?></li>
                    </ol>
                </nav>

                <h1 class="display-5 fw-bold mb-3"><?php echo e(__('Partenariat')); ?></h1>
                <p class="lead">
                    <?php echo e(__('Collaborons ensemble pour amplifier l\'impact de nos actions en faveur des communautés locales')); ?>

                </p>
            </div>
            <div class="col-lg-6 text-center">
                <i class="fas fa-handshake fa-5x opacity-75"></i>
            </div>
        </div>
    </div>
</section>

<!-- Pourquoi partenaire avec nous -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold"><?php echo e(__('Pourquoi collaborer avec nous ?')); ?></h2>
            <p class="text-muted"><?php echo e(__('Des raisons concrètes de nous choisir comme partenaire')); ?></p>
        </div>

        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow-sm text-center">
                    <div class="card-body">
                        <i class="fas fa-map-marked-alt fa-3x text-primary mb-3"></i>
                        <h5><?php echo e(__('Ancrage local fort')); ?></h5>
                        <p class="text-muted">
                            <?php echo e(__('Plus de 10 ans d\'expérience sur le terrain avec une connaissance approfondie des communautés du Nord Cameroun')); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow-sm text-center">
                    <div class="card-body">
                        <i class="fas fa-users fa-3x text-success mb-3"></i>
                        <h5><?php echo e(__('Équipe expérimentée')); ?></h5>
                        <p class="text-muted">
                            <?php echo e(__('Une équipe multidisciplinaire avec des compétences reconnues en développement communautaire et gestion de projet')); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow-sm text-center">
                    <div class="card-body">
                        <i class="fas fa-chart-line fa-3x text-info mb-3"></i>
                        <h5><?php echo e(__('Résultats mesurables')); ?></h5>
                        <p class="text-muted">
                            <?php echo e(__('Approche basée sur les preuves avec suivi-évaluation rigoureux et rapportage transparent de nos interventions')); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow-sm text-center">
                    <div class="card-body">
                        <i class="fas fa-handshake fa-3x text-warning mb-3"></i>
                        <h5><?php echo e(__('Réseau établi')); ?></h5>
                        <p class="text-muted">
                            <?php echo e(__('Partenariats existants avec institutions locales, ONG internationales et organisations communautaires')); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow-sm text-center">
                    <div class="card-body">
                        <i class="fas fa-leaf fa-3x text-success mb-3"></i>
                        <h5><?php echo e(__('Approche durable')); ?></h5>
                        <p class="text-muted">
                            <?php echo e(__('Focus sur la durabilité environnementale et sociale avec transfert de compétences aux communautés')); ?>

                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow-sm text-center">
                    <div class="card-body">
                        <i class="fas fa-shield-alt fa-3x text-danger mb-3"></i>
                        <h5><?php echo e(__('Gestion transparente')); ?></h5>
                        <p class="text-muted">
                            <?php echo e(__('Gouvernance rigoureuse avec audit externe et publication régulière de nos rapports d\'activités')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Types de partenariat -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold"><?php echo e(__('Types de partenariat')); ?></h2>
            <p class="text-muted"><?php echo e(__('Différentes modalités de collaboration selon vos objectifs')); ?></p>
        </div>

        <div class="row">
            <div class="col-lg-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <i class="fas fa-coins fa-2x text-primary me-3"></i>
                            <div>
                                <h5 class="mb-1"><?php echo e(__('Partenariat financier')); ?></h5>
                                <small class="text-muted"><?php echo e(__('Financement de projets')); ?></small>
                            </div>
                        </div>
                        <p class="mb-3"><?php echo e(__('Financement direct ou co-financement de nos projets de développement communautaire.')); ?></p>
                        <ul class="list-unstyled small">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Subventions de projets')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Financement institutionnel')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Appui budgétaire')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <i class="fas fa-cogs fa-2x text-success me-3"></i>
                            <div>
                                <h5 class="mb-1"><?php echo e(__('Partenariat technique')); ?></h5>
                                <small class="text-muted"><?php echo e(__('Expertise et savoir-faire')); ?></small>
                            </div>
                        </div>
                        <p class="mb-3"><?php echo e(__('Mise à disposition d\'expertise technique et renforcement mutuel des capacités.')); ?></p>
                        <ul class="list-unstyled small">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Assistance technique')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Formation du personnel')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Échange d\'expertises')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <i class="fas fa-network-wired fa-2x text-info me-3"></i>
                            <div>
                                <h5 class="mb-1"><?php echo e(__('Partenariat stratégique')); ?></h5>
                                <small class="text-muted"><?php echo e(__('Alliance long terme')); ?></small>
                            </div>
                        </div>
                        <p class="mb-3"><?php echo e(__('Collaboration stratégique pour maximiser l\'impact et développer des synergies.')); ?></p>
                        <ul class="list-unstyled small">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Programmation conjointe')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Mise en réseau')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Plaidoyer commun')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body">
                        <div class="d-flex align-items-start mb-3">
                            <i class="fas fa-university fa-2x text-warning me-3"></i>
                            <div>
                                <h5 class="mb-1"><?php echo e(__('Partenariat académique')); ?></h5>
                                <small class="text-muted"><?php echo e(__('Recherche et innovation')); ?></small>
                            </div>
                        </div>
                        <p class="mb-3"><?php echo e(__('Collaboration avec universités et centres de recherche pour l\'innovation sociale.')); ?></p>
                        <ul class="list-unstyled small">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Recherche-action')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Stages et mémoires')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Publications conjointes')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Nos partenaires actuels -->
<section class="py-5">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold"><?php echo e(__('Ils nous font confiance')); ?></h2>
            <p class="text-muted"><?php echo e(__('Nos partenaires institutionnels et techniques')); ?></p>
        </div>

        <div class="row align-items-center">
            <div class="col-lg-3 col-md-4 col-6 mb-4">
                <div class="card border-0 bg-light h-100">
                    <div class="card-body text-center">
                        <div class="mb-2">
                            <i class="fas fa-flag fa-2x text-primary"></i>
                        </div>
                        <h6 class="fw-bold">Union Européenne</h6>
                        <small class="text-muted"><?php echo e(__('Bailleur de fonds')); ?></small>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-6 mb-4">
                <div class="card border-0 bg-light h-100">
                    <div class="card-body text-center">
                        <div class="mb-2">
                            <i class="fas fa-globe-americas fa-2x text-info"></i>
                        </div>
                        <h6 class="fw-bold">USAID</h6>
                        <small class="text-muted"><?php echo e(__('Coopération technique')); ?></small>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-6 mb-4">
                <div class="card border-0 bg-light h-100">
                    <div class="card-body text-center">
                        <div class="mb-2">
                            <i class="fas fa-building fa-2x text-success"></i>
                        </div>
                        <h6 class="fw-bold">GIZ</h6>
                        <small class="text-muted"><?php echo e(__('Partenaire technique')); ?></small>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4 col-6 mb-4">
                <div class="card border-0 bg-light h-100">
                    <div class="card-body text-center">
                        <div class="mb-2">
                            <i class="fas fa-question fa-2x text-warning"></i>
                        </div>
                        <h6 class="fw-bold"><?php echo e(__('Votre organisation')); ?></h6>
                        <small class="text-muted"><?php echo e(__('Futur partenaire ?')); ?></small>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Processus de partenariat -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="text-center mb-5">
            <h2 class="fw-bold"><?php echo e(__('Comment devenir partenaire ?')); ?></h2>
            <p class="text-muted"><?php echo e(__('Un processus simple et transparent')); ?></p>
        </div>

        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3"
                         style="width: 80px; height: 80px;">
                        <span class="fw-bold fs-3">1</span>
                    </div>
                    <h5 class="fw-bold"><?php echo e(__('Contact initial')); ?></h5>
                    <p class="text-muted"><?php echo e(__('Envoyez-nous votre demande via notre formulaire ou contactez-nous directement')); ?></p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3"
                         style="width: 80px; height: 80px;">
                        <span class="fw-bold fs-3">2</span>
                    </div>
                    <h5 class="fw-bold"><?php echo e(__('Échange et évaluation')); ?></h5>
                    <p class="text-muted"><?php echo e(__('Rencontre pour discuter de vos objectifs et évaluer les synergies possibles')); ?></p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3"
                         style="width: 80px; height: 80px;">
                        <span class="fw-bold fs-3">3</span>
                    </div>
                    <h5 class="fw-bold"><?php echo e(__('Élaboration commune')); ?></h5>
                    <p class="text-muted"><?php echo e(__('Co-construction de la proposition de partenariat et définition des modalités')); ?></p>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="text-center">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto mb-3"
                         style="width: 80px; height: 80px;">
                        <span class="fw-bold fs-3">4</span>
                    </div>
                    <h5 class="fw-bold"><?php echo e(__('Mise en œuvre')); ?></h5>
                    <p class="text-muted"><?php echo e(__('Signature de l\'accord et lancement effectif de notre collaboration')); ?></p>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Formulaire de contact -->
<section class="py-5">
    <div class="container-fluid">
        <div class="row">
            <div class="px-5 mx-auto">
                <div class="card shadow border-0">
                    <div class="card-header bg-primary text-white text-center">
                        <h3 class="mb-0"><?php echo e(__('Proposer un partenariat')); ?></h3>
                        <p class="mb-0 opacity-75"><?php echo e(__('Décrivez votre projet de collaboration')); ?></p>
                    </div>
                    <div class="card-body p-4">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('contact.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="type" value="partnership">
                            <input type="hidden" name="subject" value="Proposition de partenariat">

                            <!-- Informations organisation -->
                            <h5 class="mb-3"><?php echo e(__('Votre organisation')); ?></h5>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="org_name" class="form-label"><?php echo e(__('Nom de l\'organisation')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['org_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="org_name" name="org_name" value="<?php echo e(old('org_name')); ?>" required>
                                    <?php $__errorArgs = ['org_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="org_type" class="form-label"><?php echo e(__('Type d\'organisation')); ?> <span class="text-danger">*</span></label>
                                    <select class="form-select <?php $__errorArgs = ['org_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="org_type" name="org_type" required>
                                        <option value=""><?php echo e(__('Sélectionnez...')); ?></option>
                                        <option value="ngo" <?php echo e(old('org_type') == 'ngo' ? 'selected' : ''); ?>><?php echo e(__('ONG/Association')); ?></option>
                                        <option value="company" <?php echo e(old('org_type') == 'company' ? 'selected' : ''); ?>><?php echo e(__('Entreprise privée')); ?></option>
                                        <option value="institution" <?php echo e(old('org_type') == 'institution' ? 'selected' : ''); ?>><?php echo e(__('Institution publique')); ?></option>
                                        <option value="university" <?php echo e(old('org_type') == 'university' ? 'selected' : ''); ?>><?php echo e(__('Université/Recherche')); ?></option>
                                        <option value="foundation" <?php echo e(old('org_type') == 'foundation' ? 'selected' : ''); ?>><?php echo e(__('Fondation')); ?></option>
                                        <option value="other" <?php echo e(old('org_type') == 'other' ? 'selected' : ''); ?>><?php echo e(__('Autre')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['org_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label"><?php echo e(__('Personne de contact')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="position" class="form-label"><?php echo e(__('Fonction')); ?></label>
                                    <input type="text" class="form-control" id="position" name="position" value="<?php echo e(old('position')); ?>">
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label"><?php echo e(__('Email')); ?> <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label"><?php echo e(__('Téléphone')); ?></label>
                                    <input type="tel" class="form-control" id="phone" name="phone" value="<?php echo e(old('phone')); ?>">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="website" class="form-label"><?php echo e(__('Site web')); ?></label>
                                <input type="url" class="form-control" id="website" name="website" value="<?php echo e(old('website')); ?>">
                            </div>

                            <hr class="my-4">

                            <!-- Détails du partenariat -->
                            <h5 class="mb-3"><?php echo e(__('Votre proposition')); ?></h5>

                            <div class="mb-3">
                                <label for="partnership_type" class="form-label"><?php echo e(__('Type de partenariat souhaité')); ?> <span class="text-danger">*</span></label>
                                <select class="form-select <?php $__errorArgs = ['partnership_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        id="partnership_type" name="partnership_type" required>
                                    <option value=""><?php echo e(__('Sélectionnez...')); ?></option>
                                    <option value="financial" <?php echo e(old('partnership_type') == 'financial' ? 'selected' : ''); ?>><?php echo e(__('Partenariat financier')); ?></option>
                                    <option value="technical" <?php echo e(old('partnership_type') == 'technical' ? 'selected' : ''); ?>><?php echo e(__('Partenariat technique')); ?></option>
                                    <option value="strategic" <?php echo e(old('partnership_type') == 'strategic' ? 'selected' : ''); ?>><?php echo e(__('Partenariat stratégique')); ?></option>
                                    <option value="academic" <?php echo e(old('partnership_type') == 'academic' ? 'selected' : ''); ?>><?php echo e(__('Partenariat académique')); ?></option>
                                </select>
                                <?php $__errorArgs = ['partnership_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-3">
                                <label class="form-label"><?php echo e(__('Domaines d\'intervention')); ?></label>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="agriculture" name="domains[]" value="agriculture">
                                            <label class="form-check-label" for="agriculture"><?php echo e(__('Agriculture durable')); ?></label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="environment" name="domains[]" value="environment">
                                            <label class="form-check-label" for="environment"><?php echo e(__('Environnement')); ?></label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="women" name="domains[]" value="women">
                                            <label class="form-check-label" for="women"><?php echo e(__('Autonomisation femmes/jeunes')); ?></label>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="governance" name="domains[]" value="governance">
                                            <label class="form-check-label" for="governance"><?php echo e(__('Gouvernance')); ?></label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="justice" name="domains[]" value="justice">
                                            <label class="form-check-label" for="justice"><?php echo e(__('Justice sociale')); ?></label>
                                        </div>
                                        <div class="form-check">
                                            <input class="form-check-input" type="checkbox" id="energy" name="domains[]" value="energy">
                                            <label class="form-check-label" for="energy"><?php echo e(__('Énergie propre')); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="mb-4">
                                <label for="message" class="form-label"><?php echo e(__('Description de votre proposition')); ?> <span class="text-danger">*</span></label>
                                <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                          id="message" name="message" rows="6" required><?php echo e(old('message')); ?></textarea>
                                <div class="form-text"><?php echo e(__('Décrivez votre projet de partenariat, vos objectifs et les bénéfices mutuels attendus')); ?></div>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg px-5">
                                    <i class="fas fa-paper-plane me-2"></i><?php echo e(__('Envoyer la proposition')); ?>

                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact direct -->
<section class="py-5 bg-primary text-white">
    <div class="container text-center">
        <h3 class="fw-bold mb-3"><?php echo e(__('Discutons de votre projet')); ?></h3>
        <p class="mb-4"><?php echo e(__('Préférez-vous un échange direct ? Contactez-nous')); ?></p>
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="row">
                    <div class="col-md-4 mb-3">
                        <a href="tel:+237696740438" class="btn btn-light btn-lg w-100">
                            <i class="fas fa-phone me-2"></i><?php echo e(__('Appeler')); ?>

                        </a>
                    </div>
                    <div class="col-md-4 mb-3">
                        <a href="mailto:contact@actforcommunities.org" class="btn btn-outline-light btn-lg w-100">
                            <i class="fas fa-envelope me-2"></i><?php echo e(__('Email')); ?>

                        </a>
                    </div>
                    <div class="col-md-4 mb-3">
                        <a href="<?php echo e(route('contact.index')); ?>" class="btn btn-outline-light btn-lg w-100">
                            <i class="fas fa-comments me-2"></i><?php echo e(__('Échanger')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views\frontend\partnership.blade.php ENDPATH**/ ?>