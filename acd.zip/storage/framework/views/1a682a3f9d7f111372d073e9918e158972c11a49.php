<?php $__env->startSection('title', $post->title); ?>
<?php $__env->startSection('description', $post->excerpt); ?>

<?php $__env->startPush('styles'); ?>
<style>
    .article-header {
        background: linear-gradient(rgba(0,0,0,0.5), rgba(0,0,0,0.5)),
                    url('<?php echo e($post->featured_image ? asset("storage/" . $post->featured_image) : asset("images/default-article.jpg")); ?>');
        background-size: cover;
        background-position: center;
        min-height: 400px;
        color: white;
    }

    .article-content {
        font-size: 1.1rem;
        line-height: 1.8;
    }

    .article-content h2,
    .article-content h3 {
        margin-top: 2rem;
        margin-bottom: 1rem;
    }

    .article-content p {
        margin-bottom: 1.5rem;
    }

    .article-content img {
        max-width: 100%;
        height: auto;
        border-radius: 8px;
        margin: 1rem 0;
    }

    .share-buttons a {
        transition: transform 0.2s;
    }

    .share-buttons a:hover {
        transform: translateY(-2px);
    }
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Article Header -->
<section class="article-header d-flex align-items-center">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <!--nav aria-label="breadcrumb" class="mb-3">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-white"><?php echo e(__('Accueil')); ?></a></li>
                        <li class="breadcrumb-item"><a href="<?php echo e(route('posts.index')); ?>" class="text-white"><?php echo e(__('Actualités')); ?></a></li>
                        <li class="breadcrumb-item active text-white"><?php echo e(Str::limit($post->title, 50)); ?></li>
                    </ol>
                </nav-->

                <div class="mb-3">
                    <span class="badge bg-primary me-2"><?php echo e($post->category->name); ?></span>
                    <span class="badge
                        <?php if($post->type == 'news'): ?> bg-info
                        <?php elseif($post->type == 'event'): ?> bg-warning
                        <?php else: ?> bg-success <?php endif; ?>">
                        <?php if($post->type == 'news'): ?> <?php echo e(__('Actualité')); ?>

                        <?php elseif($post->type == 'event'): ?> <?php echo e(__('Événement')); ?>

                        <?php else: ?> <?php echo e(__('Article')); ?> <?php endif; ?>
                    </span>
                </div>

                <h1 class="display-4 fw-bold mb-4"><?php echo e($post->title); ?></h1>

                <div class="d-flex align-items-center text-white-50">
                    <div class="me-4">
                        <i class="fas fa-user me-1"></i><?php echo e($post->user->name); ?>

                    </div>
                    <div class="me-4">
                        <i class="fas fa-calendar me-1"></i><?php echo e($post->published_at->format('d F Y')); ?>

                    </div>
                    <div>
                        <i class="fas fa-eye me-1"></i><?php echo e($post->views_count); ?> <?php echo e(__('vues')); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Article Content -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-8">
                <article class="mb-5">
                    <!-- Excerpt -->
                    <div class="lead mb-4 p-4 bg-light rounded">
                        <?php echo e($post->excerpt); ?>

                    </div>

                    <!-- Content -->
                    <div class="article-content">
                        <?php echo $post->content; ?>

                    </div>

                    <!-- Gallery -->
                    <?php if($post->gallery && count($post->gallery) > 0): ?>
                    <div class="mt-5">
                        <h3 class="fw-bold mb-4"><?php echo e(__('Galerie photos')); ?></h3>
                        <div class="row">
                            <?php $__currentLoopData = $post->gallery; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4 mb-3">
                                <img src="<?php echo e(asset('storage/' . $image)); ?>"
                                     class="img-fluid rounded shadow"
                                     alt="Galerie <?php echo e($post->title); ?>"
                                     data-bs-toggle="modal"
                                     data-bs-target="#imageModal<?php echo e($loop->index); ?>"
                                     style="cursor: pointer;">

                                <!-- Modal for image -->
                                <div class="modal fade" id="imageModal<?php echo e($loop->index); ?>" tabindex="-1">
                                    <div class="modal-dialog modal-lg modal-dialog-centered">
                                        <div class="modal-content">
                                            <div class="modal-body p-0">
                                                <img src="<?php echo e(asset('storage/' . $image)); ?>"
                                                     class="img-fluid w-100"
                                                     alt="Galerie <?php echo e($post->title); ?>">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- Meta Information -->
                    <div class="mt-5 pt-4 border-top">
                        <div class="row align-items-center">
                            <div class="col-md-6">
                                <div class="d-flex align-items-center">
                                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center me-3"
                                         style="width: 50px; height: 50px;">
                                        <i class="fas fa-user"></i>
                                    </div>
                                    <div>
                                        <h6 class="mb-0"><?php echo e($post->user->name); ?></h6>
                                        <small class="text-muted"><?php echo e(__('Publié le')); ?> <?php echo e($post->published_at->format('d F Y')); ?></small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6 text-md-end mt-3 mt-md-0">
                                <div class="share-buttons">
                                    <span class="me-2"><?php echo e(__('Partager :')); ?></span>
                                    <a href="https://www.facebook.com/sharer/sharer.php?u=<?php echo e(urlencode(request()->fullUrl())); ?>"
                                       target="_blank" class="btn btn-outline-primary btn-sm me-1">
                                        <i class="fab fa-facebook-f"></i>
                                    </a>
                                    <a href="https://twitter.com/intent/tweet?url=<?php echo e(urlencode(request()->fullUrl())); ?>&text=<?php echo e(urlencode($post->title)); ?>"
                                       target="_blank" class="btn btn-outline-info btn-sm me-1">
                                        <i class="fab fa-twitter"></i>
                                    </a>
                                    <a href="https://www.linkedin.com/sharing/share-offsite/?url=<?php echo e(urlencode(request()->fullUrl())); ?>"
                                       target="_blank" class="btn btn-outline-primary btn-sm">
                                        <i class="fab fa-linkedin-in"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </article>

                <!-- Related Posts -->
                <?php if($relatedPosts->count() > 0): ?>
                <section class="mb-5">
                    <h2 class="section-title fw-bold mb-4"><?php echo e(__('Articles similaires')); ?></h2>
                    <div class="row">
                        <?php $__currentLoopData = $relatedPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-4 mb-4">
                            <div class="card h-100 border-0 shadow-sm">
                                <?php if($related->featured_image): ?>
                                <img src="<?php echo e(asset('storage/' . $related->featured_image)); ?>"
                                     class="card-img-top" alt="<?php echo e($related->title); ?>"
                                     style="height: 150px; object-fit: cover;">
                                <?php endif; ?>
                                <div class="card-body">
                                    <h6 class="card-title">
                                        <a href="<?php echo e(route('posts.show', $related->slug)); ?>" class="text-decoration-none">
                                            <?php echo e(Str::limit($related->title, 60)); ?>

                                        </a>
                                    </h6>
                                    <p class="card-text small text-muted">
                                        <?php echo e(Str::limit($related->excerpt, 80)); ?>

                                    </p>
                                    <small class="text-muted">
                                        <?php echo e($related->published_at->format('d/m/Y')); ?>

                                    </small>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </section>
                <?php endif; ?>
            </div>

            <!-- Sidebar -->
            <div class="col-lg-4">
                <!-- Article Info -->
                <div class="card shadow mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0"><i class="fas fa-info-circle me-2"></i><?php echo e(__('Informations')); ?></h5>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <strong><?php echo e(__('Catégorie :')); ?></strong><br>
                            <span class="badge bg-secondary"> <?php echo e(Str::limit($post->category->name, 40)); ?></span>
                        </div>
                        <div class="mb-3">
                            <strong><?php echo e(__('Type :')); ?></strong><br>
                            <span class="badge
                                <?php if($post->type == 'news'): ?> bg-info
                                <?php elseif($post->type == 'event'): ?> bg-warning
                                <?php else: ?> bg-success <?php endif; ?>">
                                <?php if($post->type == 'news'): ?> <?php echo e(__('Actualité')); ?>

                                <?php elseif($post->type == 'event'): ?> <?php echo e(__('Événement')); ?>

                                <?php else: ?> <?php echo e(__('Article')); ?> <?php endif; ?>
                            </span>
                        </div>
                        <div class="mb-3">
                            <strong><?php echo e(__('Publié le :')); ?></strong><br>
                            <?php echo e($post->published_at->format('d F Y à H:i')); ?>

                        </div>
                        <div>
                            <strong><?php echo e(__('Vues :')); ?></strong><br>
                            <i class="fas fa-eye me-1"></i><?php echo e($post->views_count); ?>

                        </div>
                    </div>
                </div>

                <!-- Recent Posts -->
                <?php if($recentPosts->count() > 0): ?>
                <div class="card shadow mb-4">
                    <div class="card-header">
                        <h5 class="mb-0"><i class="fas fa-newspaper me-2"></i><?php echo e(__('Articles récents')); ?></h5>
                    </div>
                    <div class="card-body">
                        <?php $__currentLoopData = $recentPosts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="d-flex mb-3 <?php echo e(!$loop->last ? 'pb-3 border-bottom' : ''); ?>">
                            <?php if($recent->featured_image): ?>
                            <img src="<?php echo e(asset('storage/' . $recent->featured_image)); ?>"
                                 class="me-3 rounded" alt="<?php echo e($recent->title); ?>"
                                 style="width: 50px; height: 50px; object-fit: cover;">
                            <?php endif; ?>
                            <div class="flex-grow-1">
                                <h6 class="mb-1 small">
                                    <a href="<?php echo e(route('posts.show', $recent->slug)); ?>" class="text-decoration-none">
                                        <?php echo e(Str::limit($recent->title, 50)); ?>

                                    </a>
                                </h6>
                                <small class="text-muted">
                                    <?php echo e($recent->published_at->format('d/m/Y')); ?>

                                </small>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Contact -->
                <div class="card shadow bg-light">
                    <div class="card-body text-center">
                        <h5><?php echo e(__('Une question ?')); ?></h5>
                        <p class="small text-muted"><?php echo e(__('Contactez-nous pour plus d\'informations')); ?></p>
                        <a href="<?php echo e(route('contact.index')); ?>" class="btn btn-primary">
                            <i class="fas fa-envelope me-2"></i><?php echo e(__('Nous contacter')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Navigation -->
<section class="py-4 bg-light">
    <div class="container">
        <div class="row">
            <div class="col-6">
                <?php if($prevPost = \App\Models\Post::published()->where('id', '<', $post->id)->orderBy('id', 'desc')->first()): ?>
                <a href="<?php echo e(route('posts.show', $prevPost->slug)); ?>" class="btn btn-outline-secondary">
                    <i class="fas fa-arrow-left me-2"></i><?php echo e(__('Article précédent')); ?>

                </a>
                <?php endif; ?>
            </div>
            <div class="col-6 text-end">
                <?php if($nextPost = \App\Models\Post::published()->where('id', '>', $post->id)->orderBy('id', 'asc')->first()): ?>
                <a href="<?php echo e(route('posts.show', $nextPost->slug)); ?>" class="btn btn-outline-secondary">
                    <?php echo e(__('Article suivant')); ?><i class="fas fa-arrow-right ms-2"></i>
                </a>
                <?php endif; ?>
            </div>
        </div>
        <div class="text-center mt-3">
            <a href="<?php echo e(route('posts.index')); ?>" class="btn btn-primary">
                <i class="fas fa-list me-2"></i><?php echo e(__('Tous les articles')); ?>

            </a>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views/frontend/posts/show.blade.php ENDPATH**/ ?>