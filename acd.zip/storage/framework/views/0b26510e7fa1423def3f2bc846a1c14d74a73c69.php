<?php $__env->startSection('title', 'Modifier la catégorie'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Modifier la catégorie</h1>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('admin.categories.update', $category)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="name" class="form-label">Nom</label>
                <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name', $category->name)); ?>" required>
            </div>
            <div class="mb-3">
                <label for="description" class="form-label">Description</label>
                <textarea class="form-control" id="description" name="description" rows="3"><?php echo e(old('description', $category->description)); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="color" class="form-label">Couleur</label>
                <input type="color" class="form-control form-control-color" id="color" name="color" value="<?php echo e(old('color', $category->color)); ?>" required>
            </div>
            <div class="mb-3">
                <label for="icon" class="form-label">Icône</label>
                <input type="text" class="form-control" id="icon" name="icon" value="<?php echo e(old('icon', $category->icon)); ?>" required>
            </div>
            <div class="mb-3 form-check">
                <input type="hidden" name="is_active" value="0">
                <input type="checkbox" class="form-check-input" id="is_active" name="is_active" value="1" <?php echo e($category->is_active ? 'checked' : ''); ?>>
                <label class="form-check-label" for="is_active">Active</label>
            </div>
            <div class="d-flex justify-content-between">
                <a href="<?php echo e(route('admin.categories.index')); ?>" class="btn btn-secondary">Annuler</a>
                <button type="submit" class="btn btn-primary">Mettre à jour</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views\admin\categories\edit.blade.php ENDPATH**/ ?>