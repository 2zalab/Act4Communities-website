<?php $__env->startSection('title', $category->name . ' - Ressources'); ?>
<?php $__env->startSection('description', $category->description ?: 'Découvrez les ressources de la catégorie ' . $category->name); ?>

<?php $__env->startSection('content'); ?>

<!-- Breadcrumb -->
<nav aria-label="breadcrumb" class="bg-light py-2">
    <div class="container-fluid px-5">
        <ol class="breadcrumb mb-0">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>"><?php echo e(__('Accueil')); ?></a></li>
            <li class="breadcrumb-item"><a href="<?php echo e(route('resources.index')); ?>"><?php echo e(__('Ressources')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
        </ol>
    </div>
</nav>

<!-- En-tête de catégorie -->
<section class="category-header-section py-5 position-relative overflow-hidden">
    <div class="container-fluid px-5">
        <div class="row align-items-center">
            <div class="col-lg-8 mx-auto text-center">
                <!-- Icône de la catégorie -->
                <?php if($category->icon): ?>
                    <div class="category-icon mb-4">
                        <div class="icon-container" style="background-color: <?php echo e($category->color); ?>20; border: 3px solid <?php echo e($category->color); ?>">
                            <i class="<?php echo e($category->icon); ?>" style="color: <?php echo e($category->color); ?>"></i>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Titre -->
                <h1 class="display-4 fw-bold text-dark mb-4">
                    <?php echo e($category->name); ?>

                </h1>

                <!-- Description -->
                <?php if($category->description): ?>
                    <p class="lead text-muted mb-4">
                        <?php echo e($category->description); ?>

                    </p>
                <?php endif; ?>

                <!-- Statistiques -->
                <div class="category-stats d-flex justify-content-center gap-4 mb-4">
                    <div class="stat-item">
                        <span class="stat-number text-primary fw-bold"><?php echo e($resources->total()); ?></span>
                        <small class="text-muted ms-2"><?php echo e(__('ressources')); ?></small>
                    </div>
                    <?php if($fileTypes->count() > 0): ?>
                        <div class="stat-item">
                            <span class="stat-number text-success fw-bold"><?php echo e($fileTypes->count()); ?></span>
                            <small class="text-muted ms-2"><?php echo e(__('types de fichiers')); ?></small>
                        </div>
                    <?php endif; ?>
                </div>

                <!-- Navigation rapide vers autres catégories -->
                <div class="category-navigation">
                    <div class="d-flex flex-wrap justify-content-center gap-2">
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e($cat->url); ?>"
                               class="btn btn-sm <?php echo e($cat->id === $category->id ? 'btn-primary' : 'btn-outline-secondary'); ?>">
                                <?php if($cat->icon): ?>
                                    <i class="<?php echo e($cat->icon); ?> me-1"></i>
                                <?php endif; ?>
                                <?php echo e($cat->name); ?> (<?php echo e($cat->resources_count); ?>)
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- élèments décoratifs -->
    <div class="floating-elements">
        <div class="floating-shape shape-1" style="background-color: <?php echo e($category->color); ?>"></div>
        <div class="floating-shape shape-2" style="background-color: <?php echo e($category->color); ?>"></div>
    </div>
</section>

<!-- Filtres -->
<section class="filters-section py-3 bg-light border-bottom">
    <div class="container-fluid px-5">
        <div class="row align-items-center">
            <!-- Filtres par type -->
            <div class="col-md-6">
                <form method="GET" action="<?php echo e(route('resources.category', $category->slug)); ?>" class="filter-form">
                    <div class="d-flex align-items-center gap-3">
                        <label class="form-label mb-0 text-muted"><?php echo e(__('Filtrer par type:')); ?></label>
                        <select name="type" class="form-select form-select-sm" style="width: auto;" onchange="this.form.submit()">
                            <option value=""><?php echo e(__('Tous les types')); ?></option>
                            <?php $__currentLoopData = $fileTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($type); ?>" <?php echo e(request('type') == $type ? 'selected' : ''); ?>>
                                    <?php echo e(strtoupper(str_replace('application/', '', $type))); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </form>
            </div>

            <!-- Actions -->
            <div class="col-md-6 text-end">
                <div class="d-flex justify-content-end align-items-center gap-2">
                    <!-- Retour aux ressources -->
                    <a href="<?php echo e(route('resources.index')); ?>" class="btn btn-outline-secondary btn-sm">
                        <i class="fas fa-arrow-left me-1"></i><?php echo e(__('Toutes les ressources')); ?>

                    </a>

                    <!-- Vue grille/liste (optionnel) -->
                    <div class="btn-group" role="group">
                        <button type="button" class="btn btn-outline-secondary btn-sm active" data-view="grid" onclick="toggleView('grid')">
                            <i class="fas fa-th"></i>
                        </button>
                        <button type="button" class="btn btn-outline-secondary btn-sm" data-view="list" onclick="toggleView('list')">
                            <i class="fas fa-list"></i>
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <!-- Filtres actifs -->
        <?php if(request('type')): ?>
            <div class="active-filters mt-2">
                <small class="text-muted me-2"><?php echo e(__('Filtre actif:')); ?></small>
                <span class="badge bg-primary">
                    <?php echo e(__('Type:')); ?> <?php echo e(strtoupper(str_replace('application/', '', request('type')))); ?>

                    <a href="<?php echo e(route('resources.category', $category->slug)); ?>" class="text-white ms-1">
                        <i class="fas fa-times"></i>
                    </a>
                </span>
            </div>
        <?php endif; ?>
    </div>
</section>

<!-- Liste des ressources -->
<section class="resources-list-section py-5">
    <div class="container-fluid px-5">
        <?php if($resources->count() > 0): ?>
            <!-- Grille des ressources -->
            <div class="resources-grid" id="resources-container">
                <div class="row">
                    <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-4 col-md-6 mb-4 resource-item">
                            <div class="resource-card h-100 position-relative">
                                <!-- Badge de type de fichier -->
                                <div class="file-type-badge">
                                    <i class="<?php echo e($resource->file_icon); ?>"></i>
                                    <span><?php echo e($resource->file_extension); ?></span>
                                </div>

                                <!-- Thumbnail -->
                                <div class="resource-thumbnail">
                                    <img src="<?php echo e($resource->thumbnail_url); ?>"
                                         alt="<?php echo e($resource->title); ?>"
                                         class="img-fluid">
                                    <div class="thumbnail-overlay">
                                        <a href="<?php echo e($resource->url); ?>" class="btn btn-light btn-sm me-2">
                                            <i class="fas fa-eye me-1"></i><?php echo e(__('Voir')); ?>

                                        </a>
                                        <a href="<?php echo e($resource->download_url); ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-download me-1"></i><?php echo e(__('Télécharger')); ?>

                                        </a>
                                    </div>
                                </div>

                                <!-- Contenu -->
                                <div class="resource-content p-4">
                                    <!-- Titre -->
                                    <h5 class="resource-title mb-3">
                                        <a href="<?php echo e($resource->url); ?>" class="text-decoration-none text-dark">
                                            <?php echo e($resource->title); ?>

                                        </a>
                                    </h5>

                                    <!-- Description -->
                                    <p class="resource-description text-muted mb-3">
                                        <?php echo e(Str::limit($resource->description, 100)); ?>

                                    </p>

                                    <!-- Métadonnées -->
                                    <div class="resource-meta d-flex justify-content-between align-items-center">
                                        <div class="file-info">
                                            <small class="text-muted">
                                                <i class="fas fa-weight-hanging me-1"></i><?php echo e($resource->formatted_file_size); ?>

                                            </small>
                                        </div>
                                        <div class="download-count">
                                            <small class="text-muted">
                                                <i class="fas fa-download me-1"></i><?php echo e($resource->download_count); ?>

                                            </small>
                                        </div>
                                    </div>

                                    <!-- Tags -->
                                    <?php if($resource->tags_array): ?>
                                        <div class="resource-tags mt-3">
                                            <?php $__currentLoopData = array_slice($resource->tags_array, 0, 3); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <span class="badge bg-light text-dark me-1"><?php echo e(trim($tag)); ?></span>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <!-- Pagination -->
            <div class="d-flex justify-content-center mt-5">
                <?php echo e($resources->appends(request()->query())->links()); ?>

            </div>
        <?php else: ?>
            <!-- Aucune ressource -->
            <div class="no-resources text-center py-5">
                <div class="no-results-icon mb-4">
                    <?php if($category->icon): ?>
                        <i class="<?php echo e($category->icon); ?> fa-4x text-muted opacity-50"></i>
                    <?php else: ?>
                        <i class="fas fa-folder-open fa-4x text-muted opacity-50"></i>
                    <?php endif; ?>
                </div>
                <h3 class="text-muted mb-3"><?php echo e(__('Aucune ressource dans cette catégorie')); ?></h3>
                <p class="text-muted mb-4">
                    <?php if(request('type')): ?>
                        <?php echo e(__('Aucune ressource de ce type n\'est disponible dans cette catégorie. Essayez de supprimer le filtre.')); ?>

                    <?php else: ?>
                        <?php echo e(__('Cette catégorie ne contient pas encore de ressources. Revenez bientôt !')); ?>

                    <?php endif; ?>
                </p>

                <div class="d-flex justify-content-center gap-3">
                    <?php if(request('type')): ?>
                        <a href="<?php echo e(route('resources.category', $category->slug)); ?>" class="btn btn-primary">
                            <i class="fas fa-filter me-2"></i><?php echo e(__('Supprimer les filtres')); ?>

                        </a>
                    <?php endif; ?>
                    <a href="<?php echo e(route('resources.index')); ?>" class="btn btn-outline-primary">
                        <i class="fas fa-arrow-left me-2"></i><?php echo e(__('Toutes les ressources')); ?>

                    </a>
                </div>
            </div>
        <?php endif; ?>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
<style>
/* En-tête de catégorie */
.category-header-section {
    background: linear-gradient(135deg, #f8fffe 0%, #f0fdfa 100%);
    min-height: 50vh;
    display: flex;
    align-items: center;
}

.category-icon {
    display: flex;
    justify-content: center;
    margin-bottom: 2rem;
}

.icon-container {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 2.5rem;
    transition: all 0.3s ease;
}

.icon-container:hover {
    transform: scale(1.1);
    box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
}

/* Statistiques */
.category-stats {
    margin-bottom: 2rem;
}

.stat-item {
    text-align: center;
}

.stat-number {
    font-size: 1.5rem;
}

/* Navigation des catégories */
.category-navigation .btn {
    margin-bottom: 0.5rem;
    transition: all 0.3s ease;
}

.category-navigation .btn:hover {
    transform: translateY(-2px);
}

/* Filtres */
.filters-section {
    border-bottom: 2px solid rgba(0, 0, 0, 0.1);
}

/* Cartes de ressources */
.resource-card {
    background: rgba(255, 255, 255, 0.95);
    border-radius: 15px;
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
    transition: all 0.3s ease;
    overflow: hidden;
    border: 1px solid rgba(255, 255, 255, 0.2);
}

.resource-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
}

/* Badge type de fichier */
.file-type-badge {
    position: absolute;
    top: 15px;
    right: 15px;
    background: rgba(255, 255, 255, 0.95);
    border-radius: 8px;
    padding: 0.5rem 0.75rem;
    font-size: 0.8rem;
    font-weight: 600;
    z-index: 2;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

/* Thumbnail */
.resource-thumbnail {
    position: relative;
    height: 200px;
    overflow: hidden;
    background: #f8f9fa;
}

.resource-thumbnail img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    transition: all 0.3s ease;
}

.thumbnail-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: all 0.3s ease;
}

.resource-card:hover .thumbnail-overlay {
    opacity: 1;
}

.resource-card:hover .resource-thumbnail img {
    transform: scale(1.1);
}

/* Contenu des ressources */
.resource-title a {
    transition: color 0.3s ease;
}

.resource-title a:hover {
    color: var(--primary-color) !important;
}

.resource-description {
    line-height: 1.6;
    font-size: 0.9rem;
}

.resource-meta {
    border-top: 1px solid rgba(0, 0, 0, 0.1);
    padding-top: 1rem;
}

.resource-tags .badge {
    font-size: 0.7rem;
    padding: 0.3rem 0.6rem;
    border: 1px solid rgba(0, 0, 0, 0.1);
}

/* Vue liste (optionnelle) */
.resources-list .resource-item {
    width: 100%;
}

.resources-list .resource-card {
    display: flex;
    flex-direction: row;
    height: auto;
}

.resources-list .resource-thumbnail {
    width: 200px;
    flex-shrink: 0;
}

.resources-list .resource-content {
    flex: 1;
    display: flex;
    flex-direction: column;
}

/* élèments flottants */
.floating-elements {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    pointer-events: none;
    z-index: 1;
}

.floating-shape {
    position: absolute;
    border-radius: 50%;
    opacity: 0.05;
}

.shape-1 {
    width: 150px;
    height: 150px;
    top: 10%;
    right: 10%;
    animation: float 8s ease-in-out infinite;
}

.shape-2 {
    width: 100px;
    height: 100px;
    bottom: 20%;
    left: 10%;
    animation: float 6s ease-in-out infinite reverse;
}

@keyframes float {
    0%, 100% { transform: translateY(0px) rotate(0deg); }
    50% { transform: translateY(-30px) rotate(180deg); }
}

/* Responsive */
@media (max-width: 768px) {
    .category-header-section {
        min-height: 40vh;
        padding: 3rem 0;
    }

    .display-4 {
        font-size: 2rem !important;
    }

    .resource-thumbnail {
        height: 150px;
    }

    .category-navigation {
        text-align: center;
    }

    .category-navigation .btn {
        font-size: 0.8rem;
        padding: 0.4rem 0.8rem;
    }

    .resources-list .resource-card {
        flex-direction: column;
    }

    .resources-list .resource-thumbnail {
        width: 100%;
    }
}

/* Variables CSS */
:root {
    --primary-color: #059669;
    --secondary-color: #F59E0B;
    --accent-color: #10B981;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
function toggleView(view) {
    const container = document.getElementById('resources-container');
    const buttons = document.querySelectorAll('[data-view]');

    // Remove active class from all buttons
    buttons.forEach(button => button.classList.remove('active'));

    // Add active class to clicked button
    document.querySelector(`[data-view="${view}"]`).classList.add('active');

    if (view === 'list') {
        container.classList.remove('resources-grid');
        container.classList.add('resources-list');
    } else {
        container.classList.remove('resources-list');
        container.classList.add('resources-grid');
    }

    // Save preference in localStorage
    localStorage.setItem('resourcesView', view);
}

// Load saved view preference
document.addEventListener('DOMContentLoaded', function() {
    const savedView = localStorage.getItem('resourcesView');
    if (savedView) {
        toggleView(savedView);
    }
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\Projets clients\act4communities\act4communities\resources\views/frontend/resources/category.blade.php ENDPATH**/ ?>