<?php $__env->startSection('title', 'Détails de l\'utilisateur'); ?>
<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Détails de l'Utilisateur</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="<?php echo e(route('admin.users.index')); ?>" class="btn btn-sm btn-outline-secondary">
                <i class="fas fa-arrow-left me-1"></i> Retour à la liste
            </a>
        </div>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <div class="mb-3">
                    <label class="fw-bold text-muted small">NOM</label>
                    <div><?php echo e($user->name); ?></div>
                </div>
                <div class="mb-3">
                    <label class="fw-bold text-muted small">EMAIL</label>
                    <div><?php echo e($user->email); ?></div>
                </div>
                <div class="mb-3">
                    <label class="fw-bold text-muted small">STATUT</label>
                    <div>
                        <span class="badge <?php echo e($user->is_active ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($user->is_active ? 'Actif' : 'Inactif'); ?>

                        </span>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <?php if($user->avatar): ?>
                <div class="text-center">
                    <img src="<?php echo e($user->avatar); ?>" alt="Avatar" class="img-fluid rounded-circle" style="max-width: 150px;">
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views\admin\users\show.blade.php ENDPATH**/ ?>