<?php $__env->startSection('title', 'Connexion'); ?>
<?php $__env->startSection('description', 'Connexion à l\'espace administrateur d\'Act for Communities'); ?>

<?php $__env->startSection('page-title', 'Connexion'); ?>
<?php $__env->startSection('page-subtitle', 'Accédez à votre espace administrateur'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Session Status -->
    <?php if(session('status')): ?>
        <div class="status-message status-success">
            <i class="fas fa-check-circle"></i>
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <!-- Login Form -->
    <form method="POST" action="<?php echo e(route('login')); ?>" class="auth-form">
        <?php echo csrf_field(); ?>

        <!-- Email Field -->
        <div class="form-group">
            <label for="email" class="form-label"><?php echo e(__('Adresse email')); ?></label>
            <div class="input-container">
                <div class="input-icon">
                    <i class="fas fa-envelope"></i>
                </div>
                <input id="email"
                       class="form-input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       type="email"
                       name="email"
                       value="<?php echo e(old('email')); ?>"
                       required
                       autofocus
                       autocomplete="username"
                       placeholder="<?php echo e(__('votre@email.com')); ?>">
            </div>
            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="input-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Password Field -->
        <div class="form-group">
            <label for="password" class="form-label"><?php echo e(__('Mot de passe')); ?></label>
            <div class="input-container">
                <div class="input-icon">
                    <i class="fas fa-lock"></i>
                </div>
                <input id="password"
                       class="form-input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                       type="password"
                       name="password"
                       required
                       autocomplete="current-password"
                       placeholder="<?php echo e(__('••••••••')); ?>">
                <button type="button" class="password-toggle" onclick="togglePassword('password')">
                    <i class="fas fa-eye"></i>
                </button>
            </div>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="input-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <!-- Remember Me -->
        <div class="form-group-checkbox">
            <label for="remember_me" class="checkbox-label">
                <input id="remember_me" type="checkbox" class="checkbox-input" name="remember">
                <div class="checkbox-custom">
                    <i class="fas fa-check"></i>
                </div>
                <span class="checkbox-text"><?php echo e(__('Se souvenir de moi')); ?></span>
            </label>
        </div>

        <!-- Submit Button -->
        <div class="form-group">
            <button type="submit" class="btn-auth btn-primary">
                <i class="fas fa-sign-in-alt"></i>
                <?php echo e(__('Se connecter')); ?>

            </button>
        </div>

        <!-- Forgot Password Link -->
        <?php if(Route::has('password.request')): ?>
        <div class="text-center mt-4">
            <a class="auth-link" href="<?php echo e(route('password.request')); ?>">
                <i class="fas fa-key"></i>
                <?php echo e(__('Mot de passe oublié ?')); ?>

            </a>
        </div>
        <?php endif; ?>
    </form>

    <!-- Register Link -->
    <?php if(Route::has('register')): ?>
    <!--div class="auth-divider">
        <span><?php echo e(__('Nouveau sur la plateforme ?')); ?></span>
    </div-->

    <!--div class="text-center">
        <a href="<?php echo e(route('register')); ?>" class="btn-auth btn-secondary">
            <i class="fas fa-user-plus"></i>
            <?php echo e(__('Créer un compte')); ?>

        </a>
    </div-->
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\Projets clients\act4communities\act4communities\resources\views/auth/login.blade.php ENDPATH**/ ?>