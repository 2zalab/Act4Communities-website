<?php $__env->startSection('title', 'Détails de la Catégorie - ' . $resourceCategory->name); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">
        <i class="<?php echo e($resourceCategory->icon ?: 'fas fa-folder'); ?> me-2" style="color: <?php echo e($resourceCategory->color); ?>"></i>
        <?php echo e($resourceCategory->name); ?>

    </h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <div class="btn-group me-2">
            <a href="<?php echo e(route('resources.category', $resourceCategory->slug)); ?>" target="_blank" class="btn btn-outline-info">
                <i class="fas fa-eye me-2"></i>Voir sur le site
            </a>
            <a href="<?php echo e(route('admin.resource-categories.edit', $resourceCategory)); ?>" class="btn btn-outline-secondary">
                <i class="fas fa-edit me-2"></i>Modifier
            </a>
        </div>
        <a href="<?php echo e(route('admin.resource-categories.index')); ?>" class="btn btn-outline-secondary">
            <i class="fas fa-arrow-left me-2"></i>Retour à la liste
        </a>
    </div>
</div>

<!-- Informations de la catégorie -->
<div class="row mb-4">
    <!-- Informations principales -->
    <div class="col-lg-8">
        <div class="card">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-info-circle me-2"></i>
                    Informations de la catégorie
                </h5>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nom</label>
                            <div class="form-control-plaintext"><?php echo e($resourceCategory->name); ?></div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Slug (URL)</label>
                            <div class="form-control-plaintext">
                                <code><?php echo e($resourceCategory->slug); ?></code>
                                <small class="text-muted d-block">
                                    <i class="fas fa-link me-1"></i>
                                    <?php echo e(url('/resources/category/' . $resourceCategory->slug)); ?>

                                </small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label fw-bold">Description</label>
                    <div class="form-control-plaintext">
                        <?php echo e($resourceCategory->description ?: 'Aucune description'); ?>

                    </div>
                </div>

                <div class="row">
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Icône</label>
                            <div class="form-control-plaintext">
                                <?php if($resourceCategory->icon): ?>
                                    <i class="<?php echo e($resourceCategory->icon); ?> me-2" style="color: <?php echo e($resourceCategory->color); ?>; font-size: 1.5rem;"></i>
                                    <code><?php echo e($resourceCategory->icon); ?></code>
                                <?php else: ?>
                                    <span class="text-muted">Aucune icône</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Couleur</label>
                            <div class="form-control-plaintext">
                                <div class="d-flex align-items-center">
                                    <div class="color-preview me-2"
                                         style="width: 30px; height: 30px; background-color: <?php echo e($resourceCategory->color); ?>; border-radius: 50%; border: 2px solid #dee2e6;"></div>
                                    <code><?php echo e($resourceCategory->color); ?></code>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Ordre</label>
                            <div class="form-control-plaintext">
                                <span class="badge bg-secondary"><?php echo e($resourceCategory->sort_order); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Statut</label>
                            <div class="form-control-plaintext">
                                <span class="badge <?php echo e($resourceCategory->is_active ? 'bg-success' : 'bg-secondary'); ?>">
                                    <i class="fas fa-<?php echo e($resourceCategory->is_active ? 'check' : 'times'); ?> me-1"></i>
                                    <?php echo e($resourceCategory->is_active ? 'Active' : 'Inactive'); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Nombre de ressources</label>
                            <div class="form-control-plaintext">
                                <span class="badge bg-info"><?php echo e($resourceCategory->resources->count()); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Créée le</label>
                            <div class="form-control-plaintext">
                                <i class="fas fa-calendar me-1 text-muted"></i>
                                <?php echo e($resourceCategory->created_at->format('d/m/Y H:i')); ?>

                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="mb-3">
                            <label class="form-label fw-bold">Modifiée le</label>
                            <div class="form-control-plaintext">
                                <i class="fas fa-edit me-1 text-muted"></i>
                                <?php echo e($resourceCategory->updated_at->format('d/m/Y H:i')); ?>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sidebar avec aperçu -->
    <div class="col-lg-4">
        <!-- Aperçu de la catégorie -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-eye me-2"></i>
                    Aperçu
                </h5>
            </div>
            <div class="card-body">
                <div class="category-preview p-3 border rounded">
                    <div class="d-flex align-items-center">
                        <div class="icon-container rounded-circle d-flex align-items-center justify-content-center me-3"
                             style="width: 50px; height: 50px; background-color: <?php echo e($resourceCategory->color); ?>20; border: 2px solid <?php echo e($resourceCategory->color); ?>">
                            <i class="<?php echo e($resourceCategory->icon ?: 'fas fa-folder'); ?>" style="color: <?php echo e($resourceCategory->color); ?>; font-size: 1.2rem;"></i>
                        </div>
                        <div>
                            <h6 class="mb-1"><?php echo e($resourceCategory->name); ?></h6>
                            <p class="text-muted small mb-0"><?php echo e($resourceCategory->description ?: 'Aucune description'); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Actions rapides -->
        <div class="card mb-4">
            <div class="card-header">
                <h5 class="mb-0">
                    <i class="fas fa-bolt me-2"></i>
                    Actions rapides
                </h5>
            </div>
            <div class="card-body">
                <div class="d-grid gap-2">
                    <a href="<?php echo e(route('resources.category', $resourceCategory->slug)); ?>" target="_blank" class="btn btn-outline-info">
                        <i class="fas fa-eye me-2"></i>Voir sur le site
                    </a>
                    <a href="<?php echo e(route('admin.resource-categories.edit', $resourceCategory)); ?>" class="btn btn-outline-primary">
                        <i class="fas fa-edit me-2"></i>Modifier
                    </a>
                    <a href="<?php echo e(route('admin.resources.create')); ?>?category_id=<?php echo e($resourceCategory->id); ?>" class="btn btn-outline-success">
                        <i class="fas fa-plus me-2"></i>Ajouter une ressource
                    </a>
                    <button type="button" class="btn btn-outline-warning" onclick="toggleActive(<?php echo e($resourceCategory->id); ?>)">
                        <i class="fas fa-<?php echo e($resourceCategory->is_active ? 'eye-slash' : 'eye'); ?> me-2"></i>
                        <?php echo e($resourceCategory->is_active ? 'Désactiver' : 'Activer'); ?>

                    </button>
                </div>
            </div>
        </div>

        <!-- Actions danger -->
        <?php if($resourceCategory->resources->count() == 0): ?>
        <div class="card border-danger">
            <div class="card-header bg-danger text-white">
                <h5 class="mb-0">
                    <i class="fas fa-exclamation-triangle me-2"></i>
                    Zone de danger
                </h5>
            </div>
            <div class="card-body">
                <p class="text-muted small mb-3">
                    Cette catégorie ne contient aucune ressource et peut être supprimée.
                </p>
                <form method="POST" action="<?php echo e(route('admin.resource-categories.destroy', $resourceCategory)); ?>"
                      onsubmit="return confirm('Êtes-vous sûr de vouloir supprimer cette catégorie ? Cette action est irréversible.')">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm w-100">
                        <i class="fas fa-trash me-2"></i>Supprimer la catégorie
                    </button>
                </form>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<!-- Liste des ressources de cette catégorie -->
<div class="card">
    <div class="card-header">
        <div class="d-flex justify-content-between align-items-center">
            <h5 class="mb-0">
                <i class="fas fa-folder-open me-2"></i>
                Ressources dans cette catégorie (<?php echo e($resourceCategory->resources->count()); ?>)
            </h5>
            <?php if($resourceCategory->resources->count() > 0): ?>
                <a href="<?php echo e(route('admin.resources.index')); ?>?category=<?php echo e($resourceCategory->id); ?>" class="btn btn-sm btn-outline-primary">
                    <i class="fas fa-cog me-2"></i>Gérer toutes
                </a>
            <?php endif; ?>
        </div>
    </div>

    <div class="card-body p-0">
        <?php if($resourceCategory->resources->count() > 0): ?>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th width="80">Aperçu</th>
                            <th>Titre</th>
                            <th>Type</th>
                            <th>Taille</th>
                            <th>Statut</th>
                            <th>Téléchargements</th>
                            <th>Date</th>
                            <th width="150">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $resourceCategory->resources->take(10); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <div class="resource-thumbnail">
                                        <?php if($resource->thumbnail): ?>
                                            <img src="<?php echo e($resource->thumbnail_url); ?>" alt="<?php echo e($resource->title); ?>" class="img-fluid rounded" style="width: 50px; height: 50px; object-fit: cover;">
                                        <?php else: ?>
                                            <div class="bg-light rounded d-flex align-items-center justify-content-center" style="width: 50px; height: 50px;">
                                                <i class="<?php echo e($resource->file_icon); ?> fa-lg"></i>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div>
                                        <strong><?php echo e(Str::limit($resource->title, 40)); ?></strong>
                                        <?php if($resource->is_featured): ?>
                                            <span class="badge bg-warning ms-1">
                                                <i class="fas fa-star"></i>
                                            </span>
                                        <?php endif; ?>
                                    </div>
                                    <small class="text-muted"><?php echo e(Str::limit($resource->description, 60)); ?></small>
                                </td>
                                <td>
                                    <span class="badge bg-secondary">
                                        <?php echo e($resource->file_extension); ?>

                                    </span>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo e($resource->formatted_file_size); ?></small>
                                </td>
                                <td>
                                    <span class="badge <?php echo e($resource->is_published ? 'bg-success' : 'bg-secondary'); ?>">
                                        <?php echo e($resource->is_published ? 'Publié' : 'Brouillon'); ?>

                                    </span>
                                </td>
                                <td>
                                    <span class="badge bg-info"><?php echo e($resource->download_count); ?></span>
                                </td>
                                <td>
                                    <small class="text-muted"><?php echo e($resource->created_at->format('d/m/Y')); ?></small>
                                </td>
                                <td>
                                    <div class="btn-group btn-group-sm" role="group">
                                        <a href="<?php echo e($resource->url); ?>" target="_blank" class="btn btn-outline-info" title="Voir">
                                            <i class="fas fa-eye"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.resources.show', $resource)); ?>" class="btn btn-outline-primary" title="Détails">
                                            <i class="fas fa-info-circle"></i>
                                        </a>
                                        <a href="<?php echo e(route('admin.resources.edit', $resource)); ?>" class="btn btn-outline-secondary" title="Modifier">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>

            <?php if($resourceCategory->resources->count() > 10): ?>
                <div class="card-footer text-center">
                    <a href="<?php echo e(route('admin.resources.index')); ?>?category=<?php echo e($resourceCategory->id); ?>" class="btn btn-outline-primary">
                        <i class="fas fa-plus me-2"></i>Voir toutes les <?php echo e($resourceCategory->resources->count()); ?> ressources
                    </a>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <div class="text-center py-5">
                <i class="<?php echo e($resourceCategory->icon ?: 'fas fa-folder-open'); ?> fa-3x text-muted mb-3" style="color: <?php echo e($resourceCategory->color); ?>60 !important;"></i>
                <h5 class="text-muted">Aucune ressource dans cette catégorie</h5>
                <p class="text-muted">Cette catégorie ne contient pas encore de ressources.</p>
                <a href="<?php echo e(route('admin.resources.create')); ?>?category_id=<?php echo e($resourceCategory->id); ?>" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Ajouter la première ressource
                </a>
            </div>
        <?php endif; ?>
    </div>
</div>e
<style>
.category-preview {
    background: #f8f9fa;
    transition: all 0.3s ease;
}

.icon-container {
    transition: all 0.3s ease;
}

.color-preview {
    transition: transform 0.2s ease;
}

.color-preview:hover {
    transform: scale(1.1);
}

.resource-thumbnail img {
    transition: transform 0.2s ease;
}

.resource-thumbnail img:hover {
    transform: scale(1.1);
}

.table tbody tr:hover {
    background-color: rgba(0, 123, 255, 0.05);
}

.btn-group .btn {
    border-color: #dee2e6;
}

.btn-group .btn:hover {
    z-index: 2;
}
</style>

<script>
// Toggle active status
function toggleActive(categoryId) {
    fetch(`<?php echo e(route('admin.resource-categories.toggle-active', ':id')); ?>`.replace(':id', categoryId), {
        method: 'PATCH',
        headers: {
            'Content-Type': 'application/json',
            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').getAttribute('content')
        }
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            location.reload();
        } else {
            alert('Une erreur est survenue');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Une erreur est survenue');
    });
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\Projets clients\act4communities\act4communities\resources\views/admin/resource-categories/show.blade.php ENDPATH**/ ?>