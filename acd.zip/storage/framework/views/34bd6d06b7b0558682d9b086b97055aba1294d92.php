<?php $__env->startSection('title', 'Modifier l\'article'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Modifier l'article</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.posts.index')); ?>" class="btn btn-sm btn-outline-secondary">
            <i class="fas fa-arrow-left me-1"></i>Retour à la liste
        </a>
    </div>
</div>

<div class="card">
    <div class="card-body">
        <form method="POST" action="<?php echo e(route('admin.posts.update', $post)); ?>" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="mb-3">
                <label for="title" class="form-label">Titre</label>
                <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title', $post->title)); ?>" required>
            </div>
            <div class="mb-3">
                <label for="excerpt" class="form-label">Extrait</label>
                <textarea class="form-control" id="excerpt" name="excerpt" rows="3" required><?php echo e(old('excerpt', $post->excerpt)); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="content" class="form-label">Contenu</label>
                <textarea class="form-control" id="content" name="content" rows="10" required><?php echo e(old('content', $post->content)); ?></textarea>
            </div>
            <div class="mb-3">
                <label for="featured_image" class="form-label">Image mise en avant</label>
                <input type="file" class="form-control" id="featured_image" name="featured_image">
                <?php if($post->featured_image): ?>
                    <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>" alt="Featured Image" class="mt-2" style="max-width: 200px;">
                <?php endif; ?>
            </div>
            <div class="mb-3">
                <label for="category_id" class="form-label">Catégorie</label>
                <select class="form-select" id="category_id" name="category_id" required>
                    <option value="">Sélectionnez une catégorie</option>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->id); ?>" <?php echo e($post->category_id == $category->id ? 'selected' : ''); ?>>
                            <?php echo e($category->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="type" class="form-label">Type</label>
                <select class="form-select" id="type" name="type" required>
                    <option value="article" <?php echo e($post->type == 'article' ? 'selected' : ''); ?>>Article</option>
                    <option value="news" <?php echo e($post->type == 'news' ? 'selected' : ''); ?>>Actualité</option>
                    <option value="event" <?php echo e($post->type == 'event' ? 'selected' : ''); ?>>Événement</option>
                </select>
            </div>
             <div class="mb-3 form-check">
                <input type="hidden" name="is_featured" value="0">
                <input type="checkbox" class="form-check-input" id="is_featured" name="is_featured" value="1" <?php echo e($post->is_featured ? 'checked' : ''); ?>>
                <label class="form-check-label" for="is_featured">À la une</label>
            </div>

            <div class="mb-3 form-check">
                <input type="hidden" name="is_published" value="0">
                <input type="checkbox" class="form-check-input" id="is_published" name="is_published" value="1" <?php echo e($post->is_published ? 'checked' : ''); ?>>
                <label class="form-check-label" for="is_published">Publié</label>
            </div>
            <div class="mb-3">
                <label for="published_at" class="form-label">Date de publication</label>
                <input type="datetime-local" class="form-control" id="published_at" name="published_at" value="<?php echo e(old('published_at', $post->published_at ? $post->published_at->format('Y-m-d\TH:i') : '')); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Mettre à jour</button>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\Projets clients\act4communities\act4communities\resources\views/admin/posts/edit.blade.php ENDPATH**/ ?>