<?php $__env->startSection('title', 'Gestion des articles'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Gestion des Articles</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-sm btn-primary">
            <i class="fas fa-plus me-1"></i>Nouvel Article
        </a>
    </div>
</div>

<!-- Filters -->
<div class="card mb-4">
    <div class="card-body">
        <form method="GET" class="row g-3">
            <div class="col-md-3">
                <label for="type" class="form-label">Type</label>
                <select class="form-select" id="type" name="type">
                    <option value="">Tous les types</option>
                    <option value="article" <?php echo e(request('type') == 'article' ? 'selected' : ''); ?>>Article</option>
                    <option value="news" <?php echo e(request('type') == 'news' ? 'selected' : ''); ?>>Actualité</option>
                    <option value="event" <?php echo e(request('type') == 'event' ? 'selected' : ''); ?>>Événement</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="category" class="form-label">Catégorie</label>
                <select class="form-select" id="category" name="category">
                    <option value="">Toutes les catégories</option>
                    <?php $__currentLoopData = \App\Models\Category::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>" <?php echo e(request('category') == $category->id ? 'selected' : ''); ?>>
                        <?php echo e($category->name); ?>

                    </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label for="status" class="form-label">Statut</label>
                <select class="form-select" id="status" name="status">
                    <option value="">Tous les statuts</option>
                    <option value="published" <?php echo e(request('status') == 'published' ? 'selected' : ''); ?>>Publié</option>
                    <option value="draft" <?php echo e(request('status') == 'draft' ? 'selected' : ''); ?>>Brouillon</option>
                </select>
            </div>
            <div class="col-md-3">
                <label for="search" class="form-label">Recherche</label>
                <div class="input-group">
                    <input type="text" class="form-control" id="search" name="search"
                           value="<?php echo e(request('search')); ?>" placeholder="Titre, contenu...">
                    <button class="btn btn-outline-secondary" type="submit">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
        </form>
    </div>
</div>

<!-- Posts Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Liste des Articles (<?php echo e($posts->total()); ?>)</h5>
    </div>
    <div class="card-body">
        <?php if($posts->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>Article</th>
                        <th>Type</th>
                        <th>Catégorie</th>
                        <!--th>Auteur</th-->
                        <th>Statut</th>
                        <th>Publié le</th>
                        <th>Vues</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <div class="d-flex align-items-center">
                                <?php if($post->featured_image): ?>
                                <img src="<?php echo e(asset('storage/' . $post->featured_image)); ?>"
                                     class="me-3 rounded" width="50" height="50" style="object-fit: cover;">
                                <?php endif; ?>
                                <div>
                                    <h6 class="mb-0"><?php echo e($post->title); ?></h6>
                                    <small class="text-muted"><?php echo e(Str::limit($post->excerpt, 60)); ?></small>
                                    <?php if($post->is_featured): ?>
                                    <span class="badge bg-warning ms-2">À la une</span>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </td>
                        <td>
                            <span class="badge
                                <?php if($post->type == 'news'): ?> bg-info
                                <?php elseif($post->type == 'event'): ?> bg-warning
                                <?php else: ?> bg-success <?php endif; ?>">
                                <?php if($post->type == 'news'): ?> Actualité
                                <?php elseif($post->type == 'event'): ?> Événement
                                <?php else: ?> Article <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <span class="badge bg-primary"><?php echo e(\Illuminate\Support\Str::limit($post->category->name, 15)); ?></span>
                        </td>
                        <!--td><?php echo e($post->user->name); ?></td-->
                        <td>
                            <?php if($post->is_published): ?>
                            <span class="badge bg-success">Publié</span>
                            <?php else: ?>
                            <span class="badge bg-secondary">Brouillon</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($post->published_at): ?>
                            <?php echo e($post->published_at->format('d/m/Y H:i')); ?>

                            <?php else: ?>
                            <span class="text-muted">Non publié</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-light text-dark"><?php echo e($post->views_count); ?></span>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('posts.show', $post->slug)); ?>"
                                   class="btn btn-sm btn-outline-info" title="Voir" target="_blank">
                                    <i class="fas fa-eye"></i>
                                </a>
                                <a href="<?php echo e(route('admin.posts.edit', $post)); ?>"
                                   class="btn btn-sm btn-outline-primary" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.posts.destroy', $post)); ?>"
                                      class="d-inline" onsubmit="return confirm('Êtes-vous sûr ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($posts->appends(request()->query())->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-newspaper fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Aucun article trouvé</h5>
            <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i>Créer le premier article
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\Projets clients\act4communities\act4communities\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>