<?php $__env->startSection('title', 'Nous contacter'); ?>
<?php $__env->startSection('description', 'Contactez Act for Communities pour vos questions, propositions de partenariat ou pour devenir bénévole'); ?>

<?php $__env->startSection('content'); ?>
<!-- Header -->
<section class="py-5 bg-primary text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-3"><?php echo e(__('Contactez-nous')); ?></h1>
                <p class="lead">
                    <?php echo e(__('Nous sommes à votre écoute pour toute question, suggestion ou collaboration')); ?>

                </p>
            </div>
            <div class="col-lg-6 text-center">
                <i class="fas fa-envelope fa-5x opacity-75"></i>
            </div>
        </div>
    </div>
</section>

<!-- Contact Information -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100 text-center border-0 shadow">
                    <div class="card-body">
                        <i class="fas fa-phone fa-3x text-primary mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Téléphones')); ?></h5>
                        <?php $__currentLoopData = $contactInfo['phones']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <p class="card-text mb-1">
                            <a href="tel:<?php echo e($phone); ?>" class="text-decoration-none"><?php echo e($phone); ?></a>
                        </p>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100 text-center border-0 shadow">
                    <div class="card-body">
                        <i class="fas fa-building fa-3x text-primary mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Bureau')); ?></h5>
                        <p class="card-text">
                            <a href="tel:<?php echo e($contactInfo['office']); ?>" class="text-decoration-none">
                                <?php echo e($contactInfo['office']); ?>

                            </a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100 text-center border-0 shadow">
                    <div class="card-body">
                        <i class="fas fa-envelope fa-3x text-primary mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Email')); ?></h5>
                        <p class="card-text">
                            <a href="mailto:<?php echo e($contactInfo['email']); ?>" class="text-decoration-none">
                                <?php echo e($contactInfo['email']); ?>

                            </a>
                        </p>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-6 mb-4">
                <div class="card h-100 text-center border-0 shadow">
                    <div class="card-body">
                        <i class="fas fa-map-marker-alt fa-3x text-primary mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Adresse')); ?></h5>
                        <p class="card-text"><?php echo e($contactInfo['address']); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Contact Form -->
<section class="py-5 bg-light">
    <div class="container-fluid px-5">
        <div class="row">
            <div class="mx-auto">
                <div class="card shadow border-0">
                    <div class="card-header bg-white">
                        <h2 class="text-center mb-0"><?php echo e(__('Envoyez-nous un message')); ?></h2>
                    </div>
                    <div class="card-body p-5">
                        <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <i class="fas fa-check-circle me-2"></i><?php echo e(session('success')); ?>

                        </div>
                        <?php endif; ?>

                        <form method="POST" action="<?php echo e(route('contact.store')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label"><?php echo e(__('Nom complet')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label"><?php echo e(__('Adresse email')); ?> <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="email" name="email" value="<?php echo e(old('email')); ?>" required>
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label"><?php echo e(__('Téléphone')); ?></label>
                                    <input type="tel" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                           id="phone" name="phone" value="<?php echo e(old('phone')); ?>">
                                    <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                <div class="col-md-6 mb-3">
                                    <label for="type" class="form-label"><?php echo e(__('Type de demande')); ?> <span class="text-danger">*</span></label>
                                    <select class="form-select <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="type" name="type" required>
                                        <option value=""><?php echo e(__('Sélectionnez...')); ?></option>
                                        <option value="general" <?php echo e(old('type') == 'general' ? 'selected' : ''); ?>><?php echo e(__('Question générale')); ?></option>
                                        <option value="volunteer" <?php echo e(old('type') == 'volunteer' ? 'selected' : ''); ?>><?php echo e(__('Bénévolat')); ?></option>
                                        <option value="partnership" <?php echo e(old('type') == 'partnership' ? 'selected' : ''); ?>><?php echo e(__('Partenariat')); ?></option>
                                    </select>
                                    <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="subject" class="form-label"><?php echo e(__('Sujet')); ?> <span class="text-danger">*</span></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                       id="subject" name="subject" value="<?php echo e(old('subject')); ?>" required>
                                <?php $__errorArgs = ['subject'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="mb-4">
                                <label for="message" class="form-label"><?php echo e(__('Message')); ?> <span class="text-danger">*</span></label>
                                <textarea class="form-control <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                          id="message" name="message" rows="6" required><?php echo e(old('message')); ?></textarea>
                                <?php $__errorArgs = ['message'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"><?php echo e($message); ?></div>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg px-5">
                                    <i class="fas fa-paper-plane me-2"></i><?php echo e(__('Envoyer le message')); ?>

                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Quick Actions -->
<section class="py-5">
    <div class="container-fluid px-5">
        <h2 class="text-center section-title fw-bold mb-5"><?php echo e(__('Comment pouvez-vous nous aider ?')); ?></h2>
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="card h-100 text-center border-0 shadow">
                    <div class="card-body">
                        <i class="fas fa-hand-holding-heart fa-4x text-primary mb-3"></i>
                        <h4 class="card-title"><?php echo e(__('Devenir Bénévole')); ?></h4>
                        <p class="card-text">
                            <?php echo e(__('Rejoignez notre équipe de bénévoles et contribuez directement à nos missions sur le terrain')); ?>

                        </p>
                        <a href="<?php echo e(route('contact.volunteer')); ?>" class="btn btn-primary">
                            <?php echo e(__('En savoir plus')); ?>

                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mb-4">
                <div class="card h-100 text-center border-0 shadow">
                    <div class="card-body">
                        <i class="fas fa-handshake fa-4x text-primary mb-3"></i>
                        <h4 class="card-title"><?php echo e(__('Partenariat')); ?></h4>
                        <p class="card-text">
                            <?php echo e(__('Collaborez avec nous pour amplifier l\'impact de nos actions en faveur des communautés')); ?>

                        </p>
                        <a href="<?php echo e(route('contact.partnership')); ?>" class="btn btn-primary">
                            <?php echo e(__('Découvrir')); ?>

                        </a>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 mb-4">
                <div class="card h-100 text-center border-0 shadow">
                    <div class="card-body">
                        <i class="fas fa-donate fa-4x text-primary mb-3"></i>
                        <h4 class="card-title"><?php echo e(__('Nous Soutenir')); ?></h4>
                        <p class="card-text">
                            <?php echo e(__('Soutenez financièrement nos projets ou contribuez par d\'autres moyens à nos actions')); ?>

                        </p>
                        <a href="<?php echo e(route('contact.index')); ?>" class="btn btn-primary">
                            <?php echo e(__('Contribuer')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Map Section -->
<section class="py-5 bg-light">
    <div class="container-fluid px-5">
        <h2 class="text-center section-title fw-bold mb-5"><?php echo e(__('Nous situer')); ?></h2>
        <div class="row">
            <div class=" mx-auto">
                <div class="card shadow border-0">
                    <div class="card-body p-0">
                        <!-- Placeholder pour la carte - à remplacer par une vraie carte -->
                         <div class="bg-secondary d-flex align-items-center justify-content-center text-white" style="height: 400px;">
                                <div style="width: 100%; height: 100%;">
                                    <iframe
                                        src="https://www.google.com/maps?q=9.309742,13.393472&hl=fr&z=15&output=embed"
                                        width="100%"
                                        height="100%"
                                        style="border:0;"
                                        allowfullscreen=""
                                        loading="lazy"
                                        referrerpolicy="no-referrer-when-downgrade">
                                    </iframe>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views/frontend/contact.blade.php ENDPATH**/ ?>