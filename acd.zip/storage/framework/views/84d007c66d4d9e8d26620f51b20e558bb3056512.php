<?php $__env->startSection('title', 'Gestion des partenaires'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
    <h1 class="h2">Gestion des Partenaires</h1>
    <div class="btn-toolbar mb-2 mb-md-0">
        <a href="<?php echo e(route('admin.partners.create')); ?>" class="btn btn-primary">
            <i class="fas fa-plus me-1"></i>Nouveau partenaire
        </a>
    </div>
</div>

<!-- Statistics -->
<div class="row mb-4">
    <div class="col-md-3">
        <div class="card bg-info text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($partners->total()); ?></h4>
                        <p class="mb-0">Total</p>
                    </div>
                    <div>
                        <i class="fas fa-handshake fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-success text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($partners->where('is_active', true)->count()); ?></h4>
                        <p class="mb-0">Actifs</p>
                    </div>
                    <div>
                        <i class="fas fa-check-circle fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-primary text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($partners->where('type', 'partner')->count()); ?></h4>
                        <p class="mb-0">Partenaires</p>
                    </div>
                    <div>
                        <i class="fas fa-users fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-3">
        <div class="card bg-warning text-white">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <div>
                        <h4><?php echo e($partners->where('type', 'sponsor')->count()); ?></h4>
                        <p class="mb-0">Sponsors</p>
                    </div>
                    <div>
                        <i class="fas fa-star fa-2x opacity-75"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Partners Table -->
<div class="card">
    <div class="card-header">
        <h5 class="mb-0">Liste des partenaires (<?php echo e($partners->total()); ?>)</h5>
    </div>
    <div class="card-body">
        <?php if($partners->count() > 0): ?>
        <div class="table-responsive">
            <table class="table table-hover">
                <thead>
                    <tr>
                        <th>Logo</th>
                        <th>Nom</th>
                        <th>Type</th>
                        <th>Site web</th>
                        <th>Statut</th>
                        <th>Ordre</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $partner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php if($partner->logo): ?>
                            <img src="<?php echo e(Storage::url($partner->logo)); ?>"
                                 alt="<?php echo e($partner->name); ?>"
                                 class="img-thumbnail"
                                 style="width: 50px; height: 50px; object-fit: contain;">
                            <?php else: ?>
                            <div class="bg-light d-flex align-items-center justify-content-center"
                                 style="width: 50px; height: 50px; border-radius: 4px;">
                                <i class="fas fa-image text-muted"></i>
                            </div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div>
                                <strong><?php echo e($partner->name); ?></strong>
                                <?php if($partner->description): ?>
                                <div class="small text-muted text-truncate" style="max-width: 200px;">
                                    <?php echo e(Str::limit($partner->description, 50)); ?>

                                </div>
                                <?php endif; ?>
                            </div>
                        </td>
                        <td>
                            <span class="badge
                                <?php if($partner->type == 'partner'): ?> bg-primary
                                <?php elseif($partner->type == 'donor'): ?> bg-success
                                <?php else: ?> bg-warning <?php endif; ?>">
                                <?php if($partner->type == 'partner'): ?> Partenaire
                                <?php elseif($partner->type == 'donor'): ?> Donateur
                                <?php else: ?> Sponsor <?php endif; ?>
                            </span>
                        </td>
                        <td>
                            <?php if($partner->website): ?>
                            <a href="<?php echo e($partner->website); ?>" target="_blank" class="text-decoration-none">
                                <i class="fas fa-external-link-alt me-1"></i>
                                <?php echo e(Str::limit($partner->website, 30)); ?>

                            </a>
                            <?php else: ?>
                            <span class="text-muted">-</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($partner->is_active): ?>
                            <span class="badge bg-success">Actif</span>
                            <?php else: ?>
                            <span class="badge bg-secondary">Inactif</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <span class="badge bg-info"><?php echo e($partner->sort_order); ?></span>
                        </td>
                        <td>
                            <div class="btn-group" role="group">
                                <a href="<?php echo e(route('admin.partners.edit', $partner)); ?>"
                                   class="btn btn-sm btn-outline-primary" title="Modifier">
                                    <i class="fas fa-edit"></i>
                                </a>
                                <form method="POST" action="<?php echo e(route('admin.partners.destroy', $partner)); ?>"
                                      class="d-inline" onsubmit="return confirm('Êtes-vous sûr ?')">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer">
                                        <i class="fas fa-trash"></i>
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="d-flex justify-content-center mt-4">
            <?php echo e($partners->links()); ?>

        </div>
        <?php else: ?>
        <div class="text-center py-4">
            <i class="fas fa-handshake fa-3x text-muted mb-3"></i>
            <h5 class="text-muted">Aucun partenaire trouvé</h5>
            <p class="text-muted">Commencez par ajouter votre premier partenaire</p>
            <a href="<?php echo e(route('admin.partners.create')); ?>" class="btn btn-primary">
                <i class="fas fa-plus me-1"></i>Ajouter un partenaire
            </a>
        </div>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views\admin\partners\index.blade.php ENDPATH**/ ?>