<?php $__env->startSection('title', 'Devenir bénévole'); ?>
<?php $__env->startSection('description', 'Rejoignez l\'équipe de bénévoles d\'Act for Communities et contribuez au développement des communautés locales'); ?>

<?php $__env->startSection('content'); ?>
<!-- Header -->
<section class="py-5 bg-success text-white">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-lg-6">
                <h1 class="display-4 fw-bold mb-3"><?php echo e(__('Devenir Bénévole')); ?></h1>
                <p class="lead">
                    <?php echo e(__('Rejoignez notre équipe et contribuez concrètement au développement des communautés')); ?>

                </p>
            </div>
            <div class="col-lg-6 text-center">
                <i class="fas fa-hand-holding-heart fa-5x opacity-75"></i>
            </div>
        </div>
    </div>
</section>

<!-- Why Volunteer -->
<section class="py-5">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <h2 class="section-title fw-bold mb-4"><?php echo e(__('Pourquoi devenir bénévole ?')); ?></h2>
                <div class="mb-4">
                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-heart fa-2x text-primary"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5><?php echo e(__('Impact Direct')); ?></h5>
                            <p><?php echo e(__('Contribuez directement à l\'amélioration des conditions de vie des communautés locales')); ?></p>
                        </div>
                    </div>

                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-users fa-2x text-primary"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5><?php echo e(__('Expérience Enrichissante')); ?></h5>
                            <p><?php echo e(__('Développez vos compétences tout en vivant une expérience humaine unique')); ?></p>
                        </div>
                    </div>

                    <div class="d-flex mb-3">
                        <div class="flex-shrink-0">
                            <i class="fas fa-globe fa-2x text-primary"></i>
                        </div>
                        <div class="flex-grow-1 ms-3">
                            <h5><?php echo e(__('Réseau Professionnel')); ?></h5>
                            <p><?php echo e(__('Élargissez votre réseau et rencontrez des personnes engagées')); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6">
                <img src="<?php echo e(asset('images/volunteers.jpg')); ?>" alt="Bénévoles" class="img-fluid">
            </div>
        </div>
    </div>
</section>

<!-- Volunteer Opportunities -->
<section class="py-5 bg-light">
    <div class="container-fluid px-5">
        <h2 class="text-center section-title fw-bold mb-5"><?php echo e(__('Opportunités de Bénévolat')); ?></h2>
        <div class="row">
            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-seedling fa-3x text-success mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Agriculture Durable')); ?></h5>
                        <p class="card-text"><?php echo e(__('Accompagnez les producteurs dans l\'adoption de pratiques agroécologiques')); ?></p>
                        <ul class="list-unstyled small text-start">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Formation des producteurs')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Suivi des cultures')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Sensibilisation environnementale')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-female fa-3x text-primary mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Autonomisation des Femmes')); ?></h5>
                        <p class="card-text"><?php echo e(__('Participez aux programmes d\'autonomisation économique des femmes rurales')); ?></p>
                        <ul class="list-unstyled small text-start">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Animation d\'ateliers')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Accompagnement individuel')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Développement d\'AGR')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-graduation-cap fa-3x text-info mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Éducation & Formation')); ?></h5>
                        <p class="card-text"><?php echo e(__('Contribuez à l\'éducation et au renforcement des capacités des communautés')); ?></p>
                        <ul class="list-unstyled small text-start">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Alphabétisation')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Formation technique')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Sensibilisation citoyenne')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-laptop fa-3x text-warning mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Communication & TIC')); ?></h5>
                        <p class="card-text"><?php echo e(__('Aidez-nous à communiquer et à développer nos outils numériques')); ?></p>
                        <ul class="list-unstyled small text-start">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Gestion réseaux sociaux')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Création de contenu')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Support technique')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-line fa-3x text-danger mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Suivi & Évaluation')); ?></h5>
                        <p class="card-text"><?php echo e(__('Participez au suivi et à l\'évaluation de l\'impact de nos projets')); ?></p>
                        <ul class="list-unstyled small text-start">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Collecte de données')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Analyse d\'impact')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Rédaction de rapports')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>

            <div class="col-lg-4 col-md-6 mb-4">
                <div class="card h-100 border-0 shadow">
                    <div class="card-body text-center">
                        <i class="fas fa-hands-helping fa-3x text-secondary mb-3"></i>
                        <h5 class="card-title"><?php echo e(__('Support Administratif')); ?></h5>
                        <p class="card-text"><?php echo e(__('Apportez votre expertise en gestion administrative et financière')); ?></p>
                        <ul class="list-unstyled small text-start">
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Gestion administrative')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Comptabilité')); ?></li>
                            <li><i class="fas fa-check text-success me-2"></i><?php echo e(__('Recherche de financements')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Requirements -->
<section class="py-5">
    <div class="container-fluid px-5">
        <div class="row">
            <div class="col-lg-8 mx-auto">
                <h2 class="text-center section-title fw-bold mb-5"><?php echo e(__('Conditions et Prérequis')); ?></h2>

                <div class="row">
                    <div class="col-md-6 mb-4">
                        <h4><i class="fas fa-user-check text-primary me-2"></i><?php echo e(__('Profil recherché')); ?></h4>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-arrow-right text-primary me-2"></i><?php echo e(__('Motivation et engagement')); ?></li>
                            <li><i class="fas fa-arrow-right text-primary me-2"></i><?php echo e(__('Esprit d\'équipe')); ?></li>
                            <li><i class="fas fa-arrow-right text-primary me-2"></i><?php echo e(__('Adaptabilité')); ?></li>
                            <li><i class="fas fa-arrow-right text-primary me-2"></i><?php echo e(__('Respect des communautés')); ?></li>
                        </ul>
                    </div>

                    <div class="col-md-6 mb-4">
                        <h4><i class="fas fa-clock text-primary me-2"></i><?php echo e(__('Engagement')); ?></h4>
                        <ul class="list-unstyled">
                            <li><i class="fas fa-arrow-right text-primary me-2"></i><?php echo e(__('Minimum 3 mois')); ?></li>
                            <li><i class="fas fa-arrow-right text-primary me-2"></i><?php echo e(__('Disponibilité flexible')); ?></li>
                            <li><i class="fas fa-arrow-right text-primary me-2"></i><?php echo e(__('Formation initiale obligatoire')); ?></li>
                            <li><i class="fas fa-arrow-right text-primary me-2"></i><?php echo e(__('Suivi régulier')); ?></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Application Form -->
<section class="py-5 bg-light">
    <div class="container-fluid">
        <div class="row">
            <div class="mx-auto px-5">
                <div class="card shadow border-0">
                    <div class="card-header bg-success text-white">
                        <h2 class="text-center mb-0"><?php echo e(__('Candidature de Bénévolat')); ?></h2>
                    </div>
                    <div class="card-body p-5">
                        <form method="POST" action="<?php echo e(route('contact.volunteer.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="type" value="volunteer">
                            <input type="hidden" name="subject" value="Candidature de bénévolat">

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="name" class="form-label"><?php echo e(__('Nom complet')); ?> <span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" id="name" name="name" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="email" class="form-label"><?php echo e(__('Email')); ?> <span class="text-danger">*</span></label>
                                    <input type="email" class="form-control" id="email" name="email" required>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label for="phone" class="form-label"><?php echo e(__('Téléphone')); ?> <span class="text-danger">*</span></label>
                                    <input type="tel" class="form-control" id="phone" name="phone" required>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label for="age" class="form-label"><?php echo e(__('Âge')); ?></label>
                                    <input type="number" class="form-control" id="age" name="age" min="18" max="65">
                                </div>
                            </div>

                            <div class="mb-3">
                                <label for="skills" class="form-label"><?php echo e(__('Compétences et expériences')); ?></label>
                                <textarea class="form-control" id="skills" name="skills" rows="3"
                                          placeholder="<?php echo e(__('Décrivez vos compétences, formations et expériences pertinentes...')); ?>"></textarea>
                            </div>

                            <div class="mb-3">
                                <label for="domains" class="form-label"><?php echo e(__('Domaines d\'intérêt')); ?> <span class="text-danger">*</span></label>
                                <select class="form-select" id="domains" name="domains" required>
                                    <option value=""><?php echo e(__('Sélectionnez un domaine')); ?></option>
                                    <option value="agriculture"><?php echo e(__('Eau, hygiène et assainissement')); ?></option>
                                    <option value="women"><?php echo e(__('Réduction des risques de catastrophe')); ?></option>
                                    <option value="education"><?php echo e(__('Promotion et protection des droits humains et du genre')); ?></option>
                                    <option value="communication"><?php echo e(__('Gouvernance et gestion durable et inclusive des ressources naturelles')); ?></option>
                                    <option value="monitoring"><?php echo e(__('Conservation de la biodiversité')); ?></option>
                                    <option value="admin"><?php echo e(__('Changements climatiques et efficacité énergétique')); ?></option>
                                </select>
                            </div>

                            <div class="mb-3">
                                <label for="availability" class="form-label"><?php echo e(__('Disponibilité')); ?></label>
                                <textarea class="form-control" id="availability" name="availability" rows="2"
                                          placeholder="<?php echo e(__('Indiquez votre disponibilité (jours, heures, période...)')); ?>"></textarea>
                            </div>

                            <div class="mb-4">
                                <label for="message" class="form-label"><?php echo e(__('Motivation')); ?> <span class="text-danger">*</span></label>
                                <textarea class="form-control" id="message" name="message" rows="4" required
                                          placeholder="<?php echo e(__('Expliquez votre motivation pour rejoindre notre équipe de bénévoles...')); ?>"></textarea>
                            </div>

                            <div class="text-center">
                                <button type="submit" class="btn btn-success btn-lg px-5">
                                    <i class="fas fa-paper-plane me-2"></i><?php echo e(__('Envoyer ma candidature')); ?>

                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Next Steps -->
<section class="py-5">
    <div class="container">
        <h2 class="text-center section-title fw-bold mb-5"><?php echo e(__('Prochaines étapes')); ?></h2>
        <div class="row">
            <div class="col-lg-3 col-md-6 mb-4 text-center">
                <div class="mb-3">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto"
                         style="width: 80px; height: 80px;">
                        <span class="fw-bold fs-3">1</span>
                    </div>
                </div>
                <h5><?php echo e(__('Candidature')); ?></h5>
                <p class="text-muted"><?php echo e(__('Envoyez votre candidature via le formulaire')); ?></p>
            </div>

            <div class="col-lg-3 col-md-6 mb-4 text-center">
                <div class="mb-3">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto"
                         style="width: 80px; height: 80px;">
                        <span class="fw-bold fs-3">2</span>
                    </div>
                </div>
                <h5><?php echo e(__('Entretien')); ?></h5>
                <p class="text-muted"><?php echo e(__('Rencontre pour mieux vous connaître')); ?></p>
            </div>

            <div class="col-lg-3 col-md-6 mb-4 text-center">
                <div class="mb-3">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto"
                         style="width: 80px; height: 80px;">
                        <span class="fw-bold fs-3">3</span>
                    </div>
                </div>
                <h5><?php echo e(__('Formation')); ?></h5>
                <p class="text-muted"><?php echo e(__('Formation initiale sur nos méthodes')); ?></p>
            </div>

            <div class="col-lg-3 col-md-6 mb-4 text-center">
                <div class="mb-3">
                    <div class="rounded-circle bg-primary text-white d-flex align-items-center justify-content-center mx-auto"
                         style="width: 80px; height: 80px;">
                        <span class="fw-bold fs-3">4</span>
                    </div>
                </div>
                <h5><?php echo e(__('Mission')); ?></h5>
                <p class="text-muted"><?php echo e(__('Début de votre mission de bénévolat')); ?></p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MIT\act4communities\act4communities\resources\views\frontend\volunteer.blade.php ENDPATH**/ ?>